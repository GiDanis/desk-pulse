"""Software version shared by runtime, installer and recursive release manifest."""
VERSION = '0.8.2-rc.1'
