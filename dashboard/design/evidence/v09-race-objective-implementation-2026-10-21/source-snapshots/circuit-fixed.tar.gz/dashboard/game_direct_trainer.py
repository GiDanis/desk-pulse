"""Direct-control learning with a prepared base and bounded exploration trials.

    Teacher imitation is a separate preparation step. This trainer performs
    reinforcement learning on actual actuator outputs, never teacher blending.
    Existing recipes migrate at an explicit episode boundary, with provenance.
"""
from copy import deepcopy
import math
import numpy as np
from game_direct import features, controls, snapshot, DirectPolicy
from game_residual import recipe as residual_recipe
from game_residual_trainer import ResidualTrainer
from game_residual_learning import ResidualPPO, OffPolicy
from game_rewards import specification


def recipe(profile):
    result = residual_recipe(profile)
    result.update(version='direct-driving-3', base=None,
        features='direct-physical-90-v1', action='direct-steer-pedal-v1',
        scales=[1., 1.], lineMap=None, teacherAtInference=False,
        exploration=[.008, .12], minStd=[.004, .05], maxStd=[.05, .30],
        reward='direct-driving-2', criticContext='task-context-1', criticInputs=94,
        potentialPrior=True,criticWarmup=512,actorRateScale=.1,anchorSteps=4096,anchorWeight=2.,
        targetNoise=.015,targetClip=.03,domainRandomization='vehicle-grip-1',candidateRestart='failed-or-two-no-gain-all-methods-1',
        explorationBlock=dict(decisions=12,pedalStd=.35,zeroEvery=3),school='driving-school-1',raceGate='five-car-retention-1',
        shaping='bounded-time-speed-potential-1')
    if profile.get('racingObjective')=='valid-time-1':
        result.update(reward='direct-driving-3',objective='valid-lap-time-1')
    if profile.get('racingCurriculum')=='graduated-1':
        result.update(version='direct-driving-4',school='mastery-then-rehearsal-1',
            evaluation='flying-pace-and-race-1',candidateRestart='safety-or-six-no-gain-1',
            verificationDecisions=4096,schoolSuccesses=2,rehearsalEvery=16,
            rollingStarts='distributed-quarter-lap-1')
    if profile.get('expertLearning')=='routed-1':result['expertLearning']='presence-separated-1'
    if profile.get('racingAnchor')=='steering-retained-1':
        result.update(anchorSteps=32768,anchorWeight=2.,anchorAxes=[16.,0.],
            rollingStarts='standing-1',candidateRestart='failed-or-two-no-gain-all-methods-1',
            verificationDecisions=2048,noGainRestart=2)
    if profile.get('directExperiment')=='prior-only':result.update(criticWarmup=0,actorRateScale=1.,anchorSteps=0,anchorWeight=0.)
    elif profile.get('directExperiment')=='slow':result.update(criticWarmup=512,actorRateScale=.01,anchorSteps=0,anchorWeight=0.)
    elif profile.get('directExperiment')=='warm':result.update(criticWarmup=2048,actorRateScale=.1,anchorSteps=0,anchorWeight=0.)
    return result


def value_potential(obs):
    x=np.asarray(obs)
    reference=9*np.sqrt(np.maximum(.1,x[...,73])/.95)
    speed=np.maximum(0,x[...,72]*60*np.cos(x[...,10]*math.pi))
    return -.25*x[...,91]+.05*np.clip(speed/reference,0,2)


class BlockExploration:
    """Exogenous pedal option; PPO stores the conditional unshifted latent.

    Given block b, raw_actual = Normal(mean, std) + b. In PPO likelihood
    ratios the same fixed b and action Jacobian cancel. The stored raw is
    raw_actual-b, so existing Gaussian gradients remain the exact conditional
    likelihood. Steering noise stays independent and small.
    """
    def configure_blocks(self,checkpoint):
        self.block=deepcopy((checkpoint or {}).get('explorationBlock')) or dict(left=0,pedal=0.,number=0)

    def pedal_bias(self):
        spec=recipe(self.public_profile if hasattr(self,'public_profile') else self.profile)['explorationBlock']
        if self.block['left']<=0:
            self.block['number']+=1;self.block['left']=spec['decisions']
            self.block['pedal']=0. if self.block['number']%spec['zeroEvery']==0 else float(np.clip(self.rng.normal(0,spec['pedalStd']),-.7,.7))
        self.block['left']-=1
        return self.block['pedal']


class DirectPPO(BlockExploration,ResidualPPO):
    def __init__(self, profile, checkpoint=None):
        inner={k:v for k,v in profile.items() if k!='controlMode'}
        super().__init__(inner, checkpoint)
        self.public_profile=deepcopy(profile)
        self.direct_spec = recipe(profile)
        self.configure_runtime(dict(self.tuning, minLogStd=np.log(self.direct_spec['minStd']).tolist(),
                                    maxLogStd=np.log(self.direct_spec['maxStd']).tolist()))
        if not checkpoint:
            self.log_std = np.log(self.direct_spec['exploration'])
        self.configure_blocks(checkpoint)
        if profile.get('expertLearning')=='routed-1' and (checkpoint or {}).get('actorAdam',{}).get('expertBlocks'):
            from game_racing_learning import RoutedAdam
            self.actor_adam=RoutedAdam(checkpoint['actorAdam'])

    def actor_backward(self,cache,derivative):
        if self.public_profile.get('expertLearning')=='routed-1':
            from game_racing_learning import routed_backward
            return routed_backward(cache,derivative)
        return super().actor_backward(cache,derivative)

    def apply_actor_gradient(self,gradient,obs,rate):
        if self.public_profile.get('expertLearning')=='routed-1':
            from game_racing_learning import apply
            self.actor_adam=apply(self.actor_adam,self.actor,gradient,rate,obs)
        else:super().apply_actor_gradient(gradient,obs,rate)

    def sample(self,obs):
        _,raw,logp,value=super().sample(obs)
        return np.tanh(raw+np.array([0.,self.pedal_bias()])),raw,logp,value

    def checkpoint(self):
        result=super().checkpoint();result['explorationBlock']=deepcopy(self.block);return result

    def value_offset(self, obs):
        return value_potential(obs)

    def policy(self):
        return snapshot(self.public_profile, self.actor)

    candidate_policy = policy


class DirectOffPolicy(BlockExploration,OffPolicy):
    def __init__(self, profile, checkpoint=None):
        inner={k:v for k,v in profile.items() if k!='controlMode'}
        super().__init__(inner, checkpoint)
        self.profile=deepcopy(profile)
        self.spec = recipe(profile)
        self.anchor_actor=np.asarray(checkpoint['anchorActor'],dtype=float) if checkpoint and checkpoint.get('anchorActor') else None
        if not checkpoint:
            self.log_std = np.log(self.spec['exploration'])
        self.configure_blocks(checkpoint)
        if profile.get('expertLearning')=='routed-1' and (checkpoint or {}).get('actorAdam',{}).get('expertBlocks'):
            from game_racing_learning import RoutedAdam
            self.actorAdam=RoutedAdam(checkpoint['actorAdam'])

    def actor_backward(self,cache,derivative):
        if self.profile.get('expertLearning')=='routed-1':
            from game_racing_learning import routed_backward
            return routed_backward(cache,derivative)
        return super().actor_backward(cache,derivative)

    def apply_actor_gradient(self,gradient,obs,rate):
        if self.profile.get('expertLearning')=='routed-1':
            from game_racing_learning import apply
            self.actorAdam=apply(self.actorAdam,self.actor,gradient,rate,obs)
        else:super().apply_actor_gradient(gradient,obs,rate)

    def sample(self,obs):
        from game_learning import forward
        mean=forward(self.actor,np.atleast_2d(obs)[...,:90],self.hidden)
        return np.tanh(mean+self.rng.normal(size=mean.shape)*np.exp(self.log_std)+np.array([0.,self.pedal_bias()]))

    def value_offset(self,obs):return value_potential(obs)

    def actor_update_ready(self):return self.transitions>=self.spec['criticWarmup']

    def actor_learning_rate(self):return self.profile['learningRate']*self.spec['actorRateScale']

    def actor_gradient(self,gradient,obs):
        if self.anchor_actor is None:return gradient
        strength=self.spec['anchorWeight']*max(0.,1-self.transitions/max(1,self.spec['anchorSteps']))
        if not strength:return gradient
        from game_learning import forward,backward
        raw,cache=forward(self.actor,obs,self.hidden,cache=True);action=np.tanh(raw)
        base=np.tanh(forward(self.anchor_actor,obs,self.hidden))
        return gradient+self.actor_backward(cache,strength*(action-base)*(1-action*action)*np.array(self.spec.get('anchorAxes',[16.,1.]))/len(obs))

    def checkpoint(self,deferred=False):
        result=super().checkpoint(deferred)
        result['anchorActor']=self.anchor_actor.tolist() if self.anchor_actor is not None else None
        result['explorationBlock']=deepcopy(self.block)
        return result

    def policy(self):
        return snapshot(self.profile, self.actor)

    candidate_policy = policy


class DirectTrainer(ResidualTrainer):
    protocol = 'direct-driving-3'
    recipe = staticmethod(recipe)
    observe = staticmethod(features)
    drive = staticmethod(controls)

    def __init__(self, profile, track_id, checkpoint=None, opponents=(), **kwargs):
        p = {**profile, 'controlMode': 'direct'}
        c = deepcopy(checkpoint or {})
        retained_learner=None
        previous=(c.get('curriculum') or {}).get('effectiveParameters') or {}
        if c.get('protocol')=='direct-driving-2' or (not c.get('learner') and not c.get('initialPolicy')) or c.get('initialPolicy',{}).get('recipe',{}).get('version')=='direct-driving-2':
            from game_direct_bootstrap import base_asset
            p['hidden']=base_asset('traffic' if p['algorithm']=='residual_tactic' else 'driving')['policy']['hidden']
        elif c.get('protocol')==self.protocol and previous.get('hidden'):p['hidden']=previous['hidden']
        if c.get('protocol')=='direct-driving-2' and previous.get('version')=='direct-driving-2':
            from game_direct_bootstrap import initial_policy
            from game_residual import key
            state=c.get('curriculum') or {};old=state.get('champion',{}).get('policy')
            archive=dict(recipe=previous,sourceCheckpoint=c.get('migrationSource') or c.get('sourceCheckpoint'),
                steps=c.get('steps',0),decisions=c.get('decisions',0),updates=state.get('updates',0),
                stats=deepcopy(state.get('stats',{})),championHash=key(old) if old else None)
            c={k:v for k,v in c.items() if k in ('steps','decisions','seconds','configuration','sourceCheckpoint','migrationSource','rng','objective')}
            c.update(protocol=self.protocol,initialPolicy=initial_policy(p),origin='Scuola guida · nuova preparazione verificata',
                lastCheck=c.get('decisions',0))
            c['curriculum']=dict(version=1,residualVersion=self.protocol,phase='pace',round=0,updates=0,
                champion=dict(policy=c['initialPolicy'],profile=p),evaluations=[],
                stats=dict(episodes=0,success=0,passes=0,contacts=0,trackLimits=0),
                execution=dict(backend='numpy',physicsHz=60,decisionHz=10),effectiveParameters=recipe(p),
                origin=c['origin'],status='Nuova scuola · storia conservata',recipeArchives=[archive],
                epochStart=dict(steps=c.get('steps',0),decisions=c.get('decisions',0)),
                migration=dict(version='direct-driving-3',actor='new-qualified-school-base',replay='archived',critics='reset'))
        elif not c.get('learner') and c.get('initialPolicy',{}).get('recipe',{}).get('version')=='direct-driving-2':
            from game_direct_bootstrap import initial_policy
            c['initialPolicy']=initial_policy(p);c['origin']='Scuola guida · base aggiornata'
        if c.get('protocol') not in (None, self.protocol):
            raise ValueError('I pesi corsia/passo non sono comandi diretti: occorre una base neurale distinta')
        if c.get('learner') and previous.get('version')=='direct-driving-3' and recipe(p).get('version')=='direct-driving-4':
            from game_direct import snapshot as direct_snapshot
            retained_learner=c.pop('learner')
            state=c['curriculum'];source=c.get('migrationSource') or c.get('sourceCheckpoint')
            archive=dict(recipe=deepcopy(previous),sourceCheckpoint=source,steps=c.get('steps',0),
                decisions=c.get('decisions',0),seconds=c.get('seconds',0),updates=state.get('updates',0),
                evaluations=deepcopy(state.get('evaluations',[])),stats=deepcopy(state.get('stats',{})))
            state.setdefault('recipeArchives',[]).append(archive)
            state.setdefault('raceChampion',deepcopy(state['champion']))
            state.update(effectiveParameters=recipe(p),evaluations=[],updates=0,
                stats=dict(episodes=0,success=0,passes=0,contacts=0,trackLimits=0,cleanLaps=0,windows=0),
                evaluationSeconds=0.,evaluationSteps=0,noGainChecks=0,
                epochStart=dict(steps=c.get('steps',0),decisions=c.get('decisions',0)),
                migration=dict(version='direct-racing-1',actor='preserved',actorOptimizer='preserved',
                    sourceCheckpoint=source,replay='archived',critics='reset',qualifications='preserved-exact-policies'),
                status='Guida conservata · nuovo obiettivo sul tempo')
            state.pop('baseMedian',None)
            c['initialPolicy']=direct_snapshot(p,retained_learner['actor'],dict(kind='preserved-driver',sourceCheckpoint=source))
            c['lastCheck']=c.get('decisions',0);c['sourceCheckpoint']=source
            for field in ('episode','preview','previewPolicy','previewTrial','previewUpdate','previewCommand','inflight','check','metric','checkCache'):
                c.pop(field,None)
        if c.get('learner'):
            if (c.get('curriculum') or {}).get('effectiveParameters') != recipe(p):
                raise ValueError('Checkpoint diretto di un’altra ricetta')
        else:
            policy = c.get('initialPolicy')
            if not policy:
                from game_direct_bootstrap import initial_policy
                policy=initial_policy(p);c['initialPolicy']=policy
            DirectPolicy(policy)
            if policy['hidden'] != p['hidden']:
                raise ValueError('Dimensione della base neurale incompatibile')
        saved_check=c.pop('check',None)
        super().__init__(p, track_id, c, opponents=opponents, **kwargs)
        if not c.get('learner'):
            from game_learning import Adam
            if isinstance(self.learner,DirectOffPolicy):self.learner.actorAdam=Adam(len(self.learner.actor))
            else:self.learner.actor_adam=Adam(len(self.learner.actor))
        if retained_learner:
            from game_learning import Adam
            from game_racing_learning import RoutedAdam
            optimizer=retained_learner.get('actorAdam')
            restored=RoutedAdam(optimizer) if p.get('expertLearning')=='routed-1' else Adam(len(self.learner.actor),optimizer)
            if isinstance(self.learner,DirectOffPolicy):self.learner.actorAdam=restored
            else:self.learner.actor_adam=restored
            self.learner.log_std=np.asarray(retained_learner.get('logStd',retained_learner.get('log_std')),dtype=float).copy()
            self.learner.rng.bit_generator.state=deepcopy(retained_learner['rng'])
        if saved_check and saved_check.get('version')=='flying-pace-and-race-1':
            from game_racing_objective import RacingCheck
            self.check=RacingCheck(saved_check['candidate'],saved_check['champion'],track_id,saved_check,
                cache=self.check_cache,race_champion=saved_check['raceChampion'])
        elif saved_check and saved_check.get('version') in ('school-gates-1','school-gates-2'):
            from game_school_lessons import make_check
            self.check=make_check(saved_check['candidate'],saved_check['champion'],track_id,saved=saved_check,cache=self.check_cache)
        if isinstance(self.learner,DirectOffPolicy) and self.learner.anchor_actor is None:
            self.learner.anchor_actor=self.learner.actor.copy()
        if self.profile.get('racingCurriculum')=='graduated-1':
            self.state.setdefault('raceChampion',deepcopy(self.state['champion']))
            self.state['trainingProfile']=deepcopy(self.profile)
            self.state['rewardVersion']=self.reward_spec['version']
        self.state['execution']['control'] = 'network-actuators'
        self.state['execution']['teacherAtInference'] = False

    def make_learner(self, profile, checkpoint):
        return (DirectPPO if profile['algorithm']=='residual_ppo' else DirectOffPolicy)(profile, checkpoint)

    def initial_policy(self, profile, checkpoint):
        if checkpoint.get('initialPolicy'):
            return snapshot(profile,checkpoint['initialPolicy']['weights'],checkpoint['initialPolicy'].get('origin'))
        return snapshot(profile, self.learner.actor)

    def reward(self, profile):
        return specification({**profile, 'controlMode': 'direct'})

    def new_episode(self,saved=None):
        episode=super().new_episode(saved)
        if saved:
            if saved.get('spec',{}).get('schoolSkill'):
                from game_school_lessons import Lesson
                return Lesson(self.track_id,saved['spec']['schoolSkill'],saved['seed'],self.profile,saved=saved)
            return episode
        number=self.state['stats']['episodes'];phase=episode.phase
        racing=self.profile.get('racingCurriculum')=='graduated-1'
        from game_racing_objective import graduated
        ready=graduated(self.state.get('schoolStats',{}),self.state.get('schoolGraduated',False))
        if racing:self.state['schoolGraduated']=ready
        lesson=(number%6<4 if not racing or not ready else number%16==15)
        if self.objective=='impara' and self.track_id=='oval-1' and lesson:
            from game_school_lessons import Lesson,SKILLS
            return Lesson(self.track_id,SKILLS[(number//16)%4 if racing and ready else number%6],episode.seed,self.profile)
        if self.profile['algorithm']=='residual_tactic' and self.decisions>=8192 and number%8==7:
            phase='grid' if number%16==7 else 'race4'
        from game_direct_bootstrap import physical_context
        from game_academy import Episode
        from game_learning import Policy
        context=physical_context(self.rng,True) if number%4==3 else None
        if racing and self.spec.get('rollingStarts')!='standing-1' and phase=='pace' and self.objective=='impara' and ready and number%2:
            # Physical rolling starts expose braking and exits without spending
            # every attempt relearning the same launch. No target enters the actor.
            from game_geometry import get_track
            track=get_track(self.track_id);start=(number//2%4)*track.length/4
            scenario=dict(start=start,speed=8.,distance=track.length,label='Passo · circuito da partenza variata',limitSeconds=100.,practiceCircuit=True)
            from game_academy import Episode
            return Episode(self.track_id,'pace',episode.seed,protocol='driving-memory-1',
                single_lap=True,reward_spec=self.reward_spec,pace_pressure=1.,context=context,scenario=scenario)
        if phase==episode.phase and context is None:return episode
        opponents=self.opponents
        if phase in ('grid','race4') and not opponents:opponents=[Policy(self.state['champion']['policy'])]
        self.state['phase']=phase
        return Episode(self.track_id,phase,episode.seed,opponents,
            protocol='driving-memory-1',objective=self.objective,bots=self.bots,
            single_lap=True,reward_spec=self.reward_spec,pace_pressure=1.,context=context)

    def tick(self):
        checking=self.check is not None
        checked_candidate=self.check.candidate if checking else None
        old_episode=self.episode;episodes=self.state['stats']['episodes']
        super().tick()
        if self.state['stats']['episodes']>episodes and old_episode.spec.get('schoolSkill'):
            skill=old_episode.spec['schoolSkill'];stats=self.state.setdefault('schoolStats',{}).setdefault(skill,dict(total=0,valid=0))
            stats['total']+=1;stats['valid']+=int(old_episode.reason=='success')
        if self.profile.get('racingCurriculum')=='graduated-1':
            from game_racing_objective import graduated
            self.state['schoolGraduated']=graduated(self.state.get('schoolStats',{}),self.state.get('schoolGraduated',False))
        if not checking or self.check is not None:return
        latest=self.state['evaluations'][-1]
        if self.profile.get('racingCurriculum')=='graduated-1':
            if latest.get('raceAccepted'):
                self.state['raceChampion']=dict(policy=deepcopy(checked_candidate),
                    profile=deepcopy(self.profile),proof=deepcopy(latest),flyingMedian=latest['candidate']['median'])
                self.state['status']='Giro e versione gara verificati' if latest['accepted'] else 'Versione gara migliorata'
            elif latest.get('raceReferenceMedian') is not None:
                self.state['raceChampion']['flyingMedian']=latest['raceReferenceMedian']
            if latest['accepted'] and not latest.get('raceAccepted'):self.state['status']='Giro migliorato · gara precedente conservata'
            self.state['lapBest']=deepcopy(self.state['champion'])
        streak=0 if latest['accepted'] or latest.get('raceAccepted') else self.state.get('noGainChecks',0)+1
        self.state['noGainChecks']=streak
        failed=latest['candidate']['valid']<3 or (not self.profile.get('racingCurriculum') and bool(latest.get('regressions')))
        if not latest['accepted'] and not latest.get('raceAccepted') and (failed or streak>=self.spec.get('noGainRestart',6 if self.profile.get('racingCurriculum')=='graduated-1' else 2)):
            from game_learning import Adam
            self.learner.actor=np.asarray(self.state['champion']['policy']['weights'],dtype=float).copy()
            if isinstance(self.learner,DirectOffPolicy):
                self.learner.target_actor=self.learner.actor.copy();self.learner.actorAdam=Adam(len(self.learner.actor))
            else:
                self.learner.actor_adam=Adam(len(self.learner.actor));self.learner.buffer=[];self.learner.pending=None
            self.state['noGainChecks']=0
            self.state['candidateRestarts']=self.state.get('candidateRestarts',0)+1
            self.state['status']='Nuovo tentativo dal campione · esperienze conservate'

    def schedule_check(self):
        if self.decisions-self.last_check<self.spec.get('verificationDecisions',2048):return
        if self.profile.get('racingCurriculum')=='graduated-1':
            from game_racing_objective import RacingCheck
            self.last_check=self.decisions;candidate=self.learner.policy()
            self.check=RacingCheck(candidate,self.state['champion']['policy'],self.track_id,cache=self.check_cache,
                race_champion=self.state.get('raceChampion'))
            self.state['status']='Verifica giri lanciati · gara separata'
            return
        from game_school_lessons import make_check
        self.last_check=self.decisions
        self.check=make_check(self.learner.policy(),self.state['champion']['policy'],self.track_id,cache=self.check_cache)
        self.state['status']='Verifica giro e fondamenti'

    def frame(self, name, number, selected, paused=False):
        rows, rays, meta = super().frame(name, number, selected, paused)
        meta['controlMode'] = 'direct'
        meta['curriculumPhase'] = 'Guida neurale diretta'
        if isinstance(self.learner,DirectOffPolicy) and not self.learner.actor_update_ready():
            meta['curriculumPhase']='Preparazione dei critic · rete alla guida'
        info = meta['residual']
        info.pop('requestedLine', None)
        info.pop('explorationMeters', None)
        info.update(base=None, control='network-actuators', teacherAtInference=False,
            explorationSteerDegrees=float(np.exp(self.learner.log_std[0])*self.preview.world.vehicle.max_steer*180/math.pi),
            explorationPedal=float(np.exp(self.learner.log_std[1])),candidateRestarts=self.state.get('candidateRestarts',0),
            stage='critic_preparation' if isinstance(self.learner,DirectOffPolicy) and not self.learner.actor_update_ready() else 'refinement')
        latest=(self.state.get('evaluations') or [{}])[-1]
        info.update(previewRole='candidate',championSeconds=self.state['champion'].get('proof',{}).get('candidate',{}).get('median') or latest.get('champion',{}).get('median'),candidateSeconds=latest.get('candidate',{}).get('median'),
            schoolSkill=self.episode.spec.get('schoolSkill','giro completo'),schoolStats=deepcopy(self.state.get('schoolStats',{})),
            pedalBlockSeconds=self.spec['explorationBlock']['decisions']/self.spec['decisionHz'])
        if self.profile.get('racingCurriculum')=='graduated-1':
            ready=self.state.get('schoolGraduated',False) or self.objective!='impara'
            info.update(timingProtocol='flying-pace-and-race-1',schoolGraduated=ready,
                objectiveStage='Ricerca del passo' if ready else 'Scuola guida',
                raceReadySeconds=self.state.get('raceChampion',{}).get('flyingMedian'),
                raceStatus=latest.get('raceDecisionLabel','Versione gara conservata'),
                lastDecisionLabel=latest.get('decisionLabel','Prima verifica da eseguire'))
            meta['curriculumPhase']=info['objectiveStage']
        if self.check and getattr(self.check,'races',None):
            proofs=self.check.races
            meta.update(activityDone=sum(bool(r.reason) for r in proofs),activityTotal=len(proofs),
                exercise='Verifica gara · cinque auto su tre giri')
            info['status']=meta['exercise'];info['schoolSkill']='verifica gara a cinque'
        return rows, rays, meta
