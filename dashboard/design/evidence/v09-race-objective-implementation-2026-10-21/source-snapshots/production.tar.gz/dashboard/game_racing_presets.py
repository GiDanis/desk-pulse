"""Versioned profile keys, shared by migration and private comparisons."""
PROFILE_KEYS=('racingObjective','racingCurriculum','expertLearning','racingAnchor',
              'episodeExploration','racingBackup','racingHorizon','raceValidationEvery')


def production_profile(profile):
    result=dict(profile)
    if 'racingObjective' in result or not result.get('algorithm','').startswith('residual_'):
        return result
    result.update(racingObjective='valid-time-1',racingCurriculum='graduated-1',
        expertLearning='routed-1',racingAnchor='steering-retained-1',raceValidationEvery=4)
    if result['algorithm']=='residual_ppo':result['episodeExploration']='coherent-pedal-1'
    return result
