import QtQuick

InboxVisual {}
