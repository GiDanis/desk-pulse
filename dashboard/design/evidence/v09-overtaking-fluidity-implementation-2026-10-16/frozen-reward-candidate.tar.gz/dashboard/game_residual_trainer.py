"""One capable pilot learns path corrections; frozen champion drives the preview."""
from copy import deepcopy
import math
import time
import hashlib
from pathlib import Path
import numpy as np
from game_academy import Episode
from game_residual import profile as make_profile,recipe,snapshot,features,controls,key,DECISION_STEPS
from game_residual_learning import ResidualPPO,OffPolicy
from game_learning import Policy,PPO
from game_catalog import configuration,scope_hash
from game_rewards import specification


def verification_key(policy,track,cases):
    # The key covers implementation, policy/base, physics, rules and exact bank.
    files=('game_residual.py','game_control.py','game_simulation.py','game_academy.py',
        'game_racecraft.py','game_rewards.py','game_geometry.py','game_contacts.py','game_residual_trainer.py','game_catalog.py')
    if not hasattr(verification_key,'code'):
        verification_key.code=hashlib.sha256(b''.join(Path(__file__).with_name(f).read_bytes() for f in files)).hexdigest()
    return key(dict(code=verification_key.code,policy=policy,configuration=configuration(track,policy['observation']),
        cases=cases,reward=specification({'algorithm':policy['algorithm']}),bank='skill-gates-3'))


class ResidualCheck:
    def __init__(self,candidate,champion,track,saved=None,cache=None):
        self.candidate=deepcopy(candidate);self.champion=deepcopy(champion);self.track=track
        self.policies=[Policy(candidate),Policy(champion)];self.cursor=0
        cases=[('pace',91001),('pace',91002),('pace',91003)]
        if candidate['algorithm']=='residual_tactic':cases += [('overtake',s) for s in (93101,93102)]+[('corner',s) for s in (93201,93202,93203,93204)]+[('defend',s) for s in (93301,93302)]
        self.episodes=[Episode(track,phase,seed,protocol='driving-memory-1',single_lap=True,reward_spec={**specification({'algorithm':candidate['algorithm']}),'evaluationRules':'spatial-rules-2'})
                       for phase,seed in cases*2]
        self.cache=cache if cache is not None else {}
        self.cases=cases;self.reused=0
        cached=self.cache.get(verification_key(champion,track,cases))
        if cached and len(cached)==len(cases):
            self.episodes[len(cases):]=[Episode(track,s['phase'],s['seed'],saved=s) for s in cached]
            self.reused=len(cases)
        if saved:
            self.reused=saved.get('reused',0)
            self.cursor=saved['cursor']
            self.episodes=[Episode(track,s['phase'],s['seed'],saved=s) for s in saved['episodes']]

    def tick(self):
        for _ in self.episodes:
            i=self.cursor%len(self.episodes);self.cursor+=1;e=self.episodes[i]
            if e.reason:continue
            e.step(self.policies[i//(len(self.episodes)//2)].act(None,world=e.world,index=0));break
        return all(e.reason for e in self.episodes)

    def result(self):
        def collect(rows):
            times=[e.age for e in rows if e.reason=='success']
            return dict(valid=len(times),total=len(rows),best=min(times) if times else None,median=float(np.median(times)) if times else None,
                results=[e.result() for e in rows])
        half=len(self.episodes)//2
        if not all(e.reason for e in self.episodes):raise ValueError('Verifica incompleta')
        for policy,rows in ((self.candidate,self.episodes[:half]),(self.champion,self.episodes[half:])):
            self.cache[verification_key(policy,self.track,self.cases)]=[e.snapshot() for e in rows]
        while len(self.cache)>4:self.cache.pop(next(iter(self.cache)))
        candidate,champion=collect(self.episodes[:3]),collect(self.episodes[half:half+3])
        traffic=sum(e.reason=='success' for e in self.episodes[3:half])
        retained=sum(e.reason=='success' for e in self.episodes[half+3:])
        regressions=[dict(phase=a.phase,seed=a.seed) for a,b in zip(self.episodes[3:half],self.episodes[half+3:]) if (b.reason=='success' and a.reason!='success') or (not b.contact_count and a.contact_count) or (not b.world.track_limits[0] and a.world.track_limits[0])]
        accepted=candidate['valid']==3 and not regressions and traffic>=retained and (champion['valid']<3 or candidate['median']<champion['median']*.999 or (traffic>retained and candidate['median']<=champion['median']*1.005))
        candidate['trafficValid']=traffic;champion['trafficValid']=retained
        if half>3:
            for result,episodes in ((candidate,self.episodes[3:half]),(champion,self.episodes[half+3:])):
                result['trafficResults']=[e.result() for e in episodes]
                result['skills']={phase:dict(valid=sum(e.reason=='success' for e in episodes if e.phase==phase),total=sum(e.phase==phase for e in episodes),tested=sum(e.phase==phase for e in episodes)) for phase in {e.phase for e in episodes}}

        candidate['retained']=accepted
        return dict(evaluationVersion='skill-gates-3',reusedChampionCases=self.reused,regressions=regressions,phase='pace',stageLabel='Giri e duelli · confronto col campione' if half>3 else 'Tre giri puliti · confronto col campione',candidate=candidate,champion=champion,accepted=accepted,policyHash=key(self.candidate))

    def snapshot(self):
        return dict(version='skill-gates-3',reused=self.reused,candidate=self.candidate,champion=self.champion,track=self.track,cursor=self.cursor,
                    episodes=[e.snapshot() for e in self.episodes])


class ResidualTrainer:
    protocol='race-residual-1'
    collecting=False
    migration=None
    memory={}

    def __init__(self,profile,track_id,checkpoint=None,opponents=(),objective='impara',view='pilot',bots=2,**kwargs):
        self.profile=deepcopy(profile);self.track_id=track_id;self.objective=objective;self.bots=bots
        self.source_checkpoint=(checkpoint or {}).get('sourceCheckpoint');self.spec=recipe(profile)
        self.reward_spec=specification(profile)
        c=deepcopy(checkpoint or {})
        saved_recipe=(c.get('curriculum') or {}).get('effectiveParameters')
        migrated=None
        if saved_recipe and saved_recipe!=self.spec:
            # Only the known reward/cutoff/rules revision is compatible. Never
            # reinterpret old replay targets, optimizers or an unfinished proof.
            old_expected={**self.spec,'version':'race-residual-2','reward':'residual-racing-1'}
            old_expected.pop('raceRulesVersion',None);old_expected.pop('cutoff',None)
            if saved_recipe!=old_expected:raise ValueError('Ricetta di apprendimento incompatibile: serve un nuovo percorso')
            self.source_checkpoint=c.get('migrationSource') or self.source_checkpoint
            migrated=c.pop('learner',None)
            for field in ('episode','preview','inflight','check','metric'):c.pop(field,None)
            state=c['curriculum']
            archive=dict(recipe=deepcopy(saved_recipe),steps=c.get('steps',0),decisions=c.get('decisions',0),
                seconds=c.get('seconds',0),sourceCheckpoint=self.source_checkpoint,
                evaluationCount=len(state.get('evaluations',[])),updates=state.get('updates',0))
            state.setdefault('recipeArchives',[]).append(archive)
            state.update(effectiveParameters=self.spec,evaluations=[],updates=0,status='Memoria conservata · nuovi premi',
                rewardEpochStart=dict(steps=c.get('steps',0),decisions=c.get('decisions',0)),
                migration=dict(version='residual-reward-2',actor='preserved',replay='archived',critics='reset'))
            # The champion and its old proof stay intact, with their provenance.
            # Only new complete evaluations certify the new training objective.
            c['lastCheck']=c.get('decisions',0)
        changed_mode=bool(c and c.get('objective','impara')!=objective)
        if changed_mode:
            for field in ('episode','preview','inflight','check'):c.pop(field,None)
            if profile['algorithm']=='residual_ppo' and c.get('learner'):c['learner'].update(buffer=[],pending=None)
        if c and c.get('protocol') not in (None,self.protocol):raise ValueError('Esperienza del vecchio percorso incompatibile')
        if c.get('configuration') and c['configuration']!=configuration(track_id,profile['observation']):
            raise ValueError('Il checkpoint appartiene a un altro contesto fisico')
        self.learner=(ResidualPPO if profile['algorithm']=='residual_ppo' else OffPolicy)(profile,c.get('learner'))
        if not c.get('learner') and c.get('initialPolicy',{}).get('weights') is not None:
            self.learner.actor=np.asarray(c['initialPolicy']['weights'],dtype=float)
            if hasattr(self.learner,'target_actor'):self.learner.target_actor=self.learner.actor.copy()
        if migrated:
            self.learner.actor=np.asarray(migrated['actor'],dtype=float).copy()
            self.learner.log_std=np.asarray(migrated.get('logStd',migrated.get('log_std')),dtype=float).copy()
            self.learner.rng.bit_generator.state=deepcopy(migrated['rng'])
            if hasattr(self.learner,'target_actor'):self.learner.target_actor=self.learner.actor.copy()
        self.opponents=[Policy(p) for p in c.get('frozenOpponents',[])] if 'frozenOpponents' in c else list(opponents)
        self.rng=np.random.default_rng(profile['seed']+709)
        if c.get('rng'):self.rng.bit_generator.state=c['rng']
        # Keep random feature layer and a zero output layer, not a dead all-zero network.
        from game_residual import initial_weights
        neutral=snapshot(profile,initial_weights(profile))
        self.state=deepcopy(c.get('curriculum')) or dict(version=1,residualVersion=self.protocol,
            phase='pace',round=0,updates=0,champion=dict(policy=neutral,profile=profile),
            evaluations=[],stats=dict(episodes=0,success=0,passes=0,contacts=0,trackLimits=0),
            status='Base pronta',execution=dict(backend='numpy',physicsHz=60,decisionHz=10),
            effectiveParameters=self.spec,origin=c.get('origin','Base verificata · correzioni neutre'))
        self.steps=int(c.get('steps',0));self.decisions=int(c.get('decisions',0));self.metric=deepcopy(c.get('metric',{}))
        self.iterator=None
        if isinstance(self.learner,PPO) and self.learner.pending is not None:self.iterator=self.learner.updates()
        self.episode=self.new_episode(c.get('episode'));self.inflight=deepcopy(c.get('inflight'))
        self.check_cache=deepcopy(c.get('checkCache',{}))
        if migrated:self.check_cache={}
        if c.get('check') and c['check'].get('version')!='skill-gates-3':c['check']=None
        self.check=ResidualCheck(c['check']['candidate'],c['check']['champion'],track_id,c['check'],cache=self.check_cache) if c.get('check') else None
        self.preview=self.new_preview(c.get('preview'));self.preview_policy=Policy(self.state['champion']['policy'])
        self.last_preview=time.monotonic();self.preview_remaining=0.;self.preview_hold=0.;self.rate_samples={}
        self.episode_serial=int(c.get('episodeSerial',0));self.last_check=int(c.get('lastCheck',0))

    @property
    def task(self):return self.episode.spec

    def new_episode(self,saved=None):
        phase='pace'
        if self.objective=='impara_sorpasso' or (self.profile['algorithm']=='residual_tactic' and self.decisions>=8192 and self.state['stats']['episodes']%4):
            choices=('overtake','defend','corner','duel') if self.opponents and self.state['stats']['episodes']>=12 else ('overtake','defend','corner')
            phase=choices[self.state['stats']['episodes']%len(choices)]
        if saved:phase=saved['phase']
        self.state['phase']=phase
        mode=self.objective
        seed=saved['seed'] if saved else int(self.rng.integers(200000,300000))
        e=Episode(self.track_id,phase,seed,self.opponents,saved=saved,
            protocol='driving-memory-1',objective=mode,bots=self.bots,single_lap=True,reward_spec=self.reward_spec,pace_pressure=1.)
        e.world.native_sensors=True
        return e

    def new_preview(self,saved=None):
        traffic=self.objective=='impara_sorpasso'
        e=Episode(self.track_id,'overtake' if traffic else 'pace',719001,saved=saved,objective='impara_sorpasso' if traffic else 'impara_infinito',bots=self.bots,protocol='driving-memory-1',reward_spec=self.reward_spec)
        e.world.enable_timing('preview');return e

    def quiesce(self):pass
    def close(self):pass

    def advance_preview(self):
        self.preview.world.enable_timing('preview').bind(0,'preview',key(self.state['champion']['policy']))
        now=time.monotonic();self.preview_remaining+=max(0,min(.1,now-self.last_preview));self.last_preview=now
        if self.preview.reason and self.preview.reason!='window':
            self.preview_hold+=self.preview_remaining;self.preview_remaining=0
            if self.preview_hold>2:self.preview=self.new_preview();self.preview_hold=0
            return
        while self.preview_remaining>=1/60:
            if self.preview.reason=='window':self.preview.next_window()
            self.preview.step(self.preview_policy.act(None,world=self.preview.world,index=0))
            self.preview_remaining-=1/60
            if self.preview.reason and self.preview.reason!='window':break

    def tick(self):
        if self.check:
            started=time.monotonic()
            done=self.check.tick()
            self.state['evaluationSeconds']=self.state.get('evaluationSeconds',0.)+time.monotonic()-started
            self.state['evaluationSteps']=self.state.get('evaluationSteps',0)+1
            if done:
                result=self.check.result();self.state['round']+=1
                if not self.state.get('baseMedian'):self.state['baseMedian']=result['champion']['median']
                result.update(round=self.state['round'],scope=scope_hash(self.track_id,self.profile['observation']))
                self.state['evaluations']=(self.state['evaluations']+[result])[-20:]
                if result['accepted']:
                    self.state['champion']=dict(policy=self.check.candidate,profile=self.profile,proof=result)
                    self.state['verifiedBest']=dict(policy=self.check.candidate,profile=self.profile,proof=result)
                    self.preview_policy=Policy(self.check.candidate)
                    self.state['status']='Miglioramento verificato'
                else:self.state['status']='Campione conservato'
                self.check=None
            return
        if self.iterator:
            try:self.metric=next(self.iterator)
            except StopIteration:
                self.iterator=None;self.state['updates']=self.learner.update_index
                self.schedule_check()
            return
        e=self.episode
        if self.inflight is None:
            obs=features(e.world)
            if isinstance(self.learner,PPO):
                action,raw,logp,value=self.learner.sample(obs[None,:])
                self.inflight=dict(obs=obs.tolist(),action=action[0].tolist(),raw=raw[0].tolist(),logp=float(logp[0]),value=float(value[0]),reward=0.,ticks=0)
            else:self.inflight=dict(obs=obs.tolist(),action=self.learner.sample(obs)[0].tolist(),reward=0.,ticks=0)
        b=self.inflight
        command=controls(e.world,b['action'],[0])[0]
        old_laps=int(e.world.clean_laps[0])
        _,reward,done,terminated=e.step(command)
        self.state['stats']['cleanLaps']=self.state['stats'].get('cleanLaps',0)+int(e.world.clean_laps[0])-old_laps
        self.steps+=1;b['ticks']+=1;b['reward']+=float(reward)
        if b['ticks']<DECISION_STEPS and not done:return
        nxt=features(e.world);self.decisions+=1
        if isinstance(self.learner,PPO):
            self.learner.remember(np.array([b['obs']]),np.array([b['raw']]),np.array([b['logp']]),np.array([b['value']]),
                np.array([b['reward']]),np.array([done]),nxt[None,:],np.array([terminated]))
            if len(self.learner.buffer)>=self.profile['rollout']:self.iterator=self.learner.updates()
        else:
            self.learner.remember(b['obs'],b['action'],b['reward'],nxt,terminated)
            result=self.learner.update()
            if result:self.metric=result;self.state['updates']=self.learner.update_index
        self.inflight=None
        self.metric.update(decisions=self.decisions,physicalSteps=self.steps,activity='Aggiornamento' if self.iterator else 'Raccolta')
        if done:
            stats=self.state['stats'];stats['episodes']+=1;stats['success']+=int(e.reason=='success')
            stats['windows']=stats.get('windows',0)+int(e.reason=='window')
            stats['passes']+=e.passes;stats['contacts']+=e.contact_count;stats['trackLimits']+=int(e.world.track_limits[0])
            self.state['lastEpisode']=e.result()
            self.state['racecraftViolations']=self.state.get('racecraftViolations',0)+getattr(e,'racecraft',{}).get('violations',0)
            if e.reason=='window':e.next_window()
            else:self.episode=self.new_episode();self.episode_serial+=1
        if self.decisions>=300000 and not self.state.get('verifiedBest'):
            self.state['pauseRequested']='Budget raggiunto senza miglioramento verificato · campione conservato'
        if not self.iterator:self.schedule_check()

    def schedule_check(self):
        # Bound verification overhead; count data and frozen verification separately.
        if self.decisions-self.last_check<(4096 if self.profile['algorithm']=='residual_tactic' else 2048):return
        self.last_check=self.decisions
        self.check=ResidualCheck(self.learner.policy(),self.state['champion']['policy'],self.track_id,cache=self.check_cache)
        self.state['status']='Verifica congelata'

    def checkpoint(self,seconds,deferred=False):
        return dict(schema=1,protocol=self.protocol,objective=self.objective,configuration=configuration(self.track_id,self.profile['observation']),
            learner=self.learner.checkpoint(deferred=True) if deferred and isinstance(self.learner,OffPolicy) else self.learner.checkpoint(),sourceCheckpoint=self.source_checkpoint,steps=self.steps,decisions=self.decisions,seconds=seconds,
            curriculum=deepcopy(self.state),metric=deepcopy(self.metric),task=self.task,
            episode=self.episode.snapshot(),preview=self.preview.snapshot(),inflight=deepcopy(self.inflight),
            check=self.check.snapshot() if self.check else None,checkCache=deepcopy(self.check_cache),rng=deepcopy(self.rng.bit_generator.state),
            episodeSerial=self.episode_serial,lastCheck=self.last_check,rewardSpec=self.reward_spec,
            frozenOpponents=[p.snapshot for p in self.opponents])

    def frame(self,name,number,selected,paused=False):
        e=self.preview;rows=e.world.rows()
        for i,row in enumerate(rows):
            row.update(id='residual-preview-'+str(i),name=name if i==0 else 'Bot '+str(i),number=number if i==0 else i,
                resetKey=str(e.revision),simulatedTime=e.world.time)
        meta=dict(driverName=name,algorithm=self.profile['algorithm'],count=len(rows),selected=selected%len(rows),
            steps=self.steps,metric=deepcopy(self.metric),phase='valutazione' if self.check else 'aggiornamento' if self.iterator else 'raccolta',
            curriculumPhase='Traiettorie e passo' if self.state['phase']=='pace' else 'Sorpassi e difesa',
            exercise=self.state['status'],evaluationRound=self.state['round'],presentation='preview',trainingCount=1,
            previewState=e.reason or 'running',manoeuvre=e.manoeuvre_status(),time=e.world.time,sensorRange=150,objective=self.objective,
            learningStats=deepcopy(self.state['stats']),execution=self.state['execution'],
            residual=dict(decisions=self.decisions,base='race-base-1',status=self.state['status'],championHash=key(self.state['champion']['policy']),
                bestImprovement=max(0.,1-(self.state['champion'].get('proof',{}).get('candidate',{}).get('median') or self.state.get('baseMedian') or 1)/(self.state.get('baseMedian') or 1))))
        if self.check:meta.update(activityDone=sum(bool(e.reason) for e in self.check.episodes),activityTotal=len(self.check.episodes))
        return rows,e.observations(),meta
