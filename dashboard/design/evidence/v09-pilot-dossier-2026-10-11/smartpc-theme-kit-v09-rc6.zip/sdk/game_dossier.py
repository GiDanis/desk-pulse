"""Read-only per-driver facts, including previous profiles and frozen results."""
from datetime import datetime

METHODS={'evolution':'Evoluzione','ppo':'PPO','neat':'NEAT'}


def duration(value):
    value=max(0,int(value));h,rest=divmod(value,3600);m,s=divmod(rest,60)
    return f'{h} h {m:02} min' if h else f'{m} min {s:02} s'


def date(value):
    return datetime.fromisoformat(value).astimezone().strftime('%d/%m/%y %H:%M')


def row(title,value,description='',identity=''):
    return dict(id=identity,title=title,value=str(value),description=description)


def profile_rows(profile,prefix=''):
    method=profile['algorithm']
    output=[row(prefix+'Metodo',METHODS[method],'Traffico attivo' if profile['traffic'] else 'Guida solitaria'),
            row('Tentativi e rete',f"{profile['population']} · {profile['hidden']} neuroni",'Tentativi paralleli; per NEAT i neuroni indicano la rete iniziale.'),
            row('Partenza ed episodio',f"Seed {profile['seed']} · {profile['episodeSeconds']} s",'Seme riproducibile e durata massima del tentativo.')]
    if method=='ppo':
        output.extend([row('Aggiornamento PPO',f"LR {profile['learningRate']} · γ {profile['gamma']}",'Passo di apprendimento e peso delle ricompense future.'),
                       row('Raccolta PPO',f"{profile['rollout']} passi · {profile['epochs']} epoche",'Esperienze raccolte e ripetizioni per aggiornamento.')])
    else:output.append(row('Mutazione',profile['mutation'],'Intensità delle variazioni della rete.'))
    return output


def dossier(store,identity):
    driver=store.driver(identity)
    if not driver:return {}
    events=store.driver_events(identity)
    resets=[e for e in events if e['kind']=='reset']
    history=[];results=[];training=[];races=arrivals=wins=0
    for session in store.sessions(complete=False):
        p=session['payload'];mode=session['mode']
        if mode=='impara' and p.get('driver')==identity:
            training.append(session)
            stats=p.get('training');profile=p.get('profile') or {}
            summary=(duration(stats['seconds'])+' · '+str(stats['steps'])+' passi') if stats else 'Durata di sessione non registrata'
            history.append({**row('Allenamento · '+METHODS.get(profile.get('algorithm'),'Metodo precedente'),summary,
                                 date(session['created'])+' · '+{'interrupted':'interrotta','paused':'in pausa','running':'in corso','complete':'conclusa','failed':'errore'}[session['status']]),'created':session['created'], 'profile':profile,'id':'session:'+session['id'],'detailRows':[row('Durata e passi',summary,'Pause escluse; i dati assenti delle sessioni precedenti non vengono stimati.')]+profile_rows(profile) if profile else []})
        people=p.get('participants',[])
        person=next((x for x in people if x['id']==identity),None)
        if mode not in ('gara','prova','campione') or not person:continue
        if session['status']!='complete':
            value='Interrotta' if session['status'] in ('interrupted','paused') else 'Errore' if session['status']=='failed' else 'In corso'
        elif mode=='prova':
            tests=[r for r in p.get('results',[]) if r['driver']==identity]
            times=[r['time'] for r in tests if r.get('time') is not None]
            value=f'{len(times)}/{len(tests)} arrivi'+(f' · migliore {min(times):.2f} s' if times else '')
        else:
            result=next((r for r in p.get('results',[]) if r['id']==identity),{})
            value=f"P{result.get('position','—')} · {result.get('status','—')} · {result.get('lap',0)} giri"
        if mode=='gara' and session['status']=='complete':
            races+=1
            if result.get('status')=='arrivato':
                arrivals+=1;wins+=int(result.get('position')==1)
        previous=person.get('policy')!=driver['policy']
        description=date(session['created'])+' · '+METHODS.get(person['profile']['algorithm'],'—')+(' · modello precedente' if previous else ' · modello attuale')
        if mode!='prova' and session['status']=='complete' and result.get('finishTime') is not None:
            description+=f" · tempo {result['finishTime']:.2f} s"
        results.append({**row({'gara':'Gara','prova':'Prova standard','campione':'Campione'}[mode],value,description),'created':session['created'],'policy':person.get('policy')})
    for event in events:
        p=event['payload'];kind=event['kind']
        if kind=='profile':
            old=p['previous'];new=p['next'];value=METHODS[new['algorithm']]+(' · nuovo percorso' if p['newPath'] else ' · parametri aggiornati')
            changes=[f'{k}: {old[k]} → {v}' for k,v in new.items() if old[k]!=v]
            description='; '.join(changes) or 'Profilo invariato'
        elif kind=='reset':value='Apprendimento azzerato';description='Nome, impostazioni e risultati precedenti conservati'
        else:
            proof=p['candidate'];value=f"{proof['valid']}/{proof['total']} giri validi"+(f" · {proof['median']:.2f} s" if proof['median'] is not None else '')
            description='Campione promosso' if p['promoted'] else 'Valutazione del candidato'
            results.append({**row('Valutazione',value,date(event['created'])+' · '+description),'created':event['created'],'id':'event:'+str(event['id']), 'detailRows':profile_rows(p['previous'],'Prima · ')+profile_rows(p['next'],'Dopo · ') if kind=='profile' else []})
        history.append({**row({'profile':'Cambio parametri','reset':'Reset','evaluation':'Valutazione'}[kind],value,date(event['created'])+' · '+description),'created':event['created'],'id':'event:'+str(event['id']), 'detailRows':profile_rows(p['previous'],'Prima · ')+profile_rows(p['next'],'Dopo · ') if kind=='profile' else []})
    state=driver['curriculum'] or {};champion=state.get('champion')
    status='Campione verificato' if champion else 'Modello precedente' if driver['policy'] else 'Candidato in allenamento' if driver['candidate'] else 'Da allenare'
    total_seconds=driver['seconds']+sum(e['payload']['previous']['seconds'] for e in resets)
    summary=[row('Pilota',driver['name'],'5 cambia pilota', 'driver'),
             row('Allenamento attuale',duration(driver['seconds']),f"{driver['steps']:,} passi · dall’ultimo reset, pause escluse"),
             row('Storico complessivo',duration(total_seconds),f'{len(training)} sessioni registrate · {len(resets)} reset'),
             row('Modello da gara',status,METHODS[(driver['policy_profile'] or driver['profile'])['algorithm']]+(' · da qualificare' if not champion else '')),
             row('Gare concluse',f'{races} · {wins} vittorie',f'{arrivals} arrivi · risultati di tutti i modelli'),
             row('Creato',date(driver['created']),'Identità persistente del pilota')]
    parameters=profile_rows(driver['profile'],'Attuale · ')
    if driver['policy_profile']:
        parameters+=profile_rows(driver['policy_profile'],'Salvato · ')
    return dict(id=identity,name=driver['name'],summary=summary,parameters=parameters,
                history=sorted(history,key=lambda x:x['created'],reverse=True),
                results=sorted(results,key=lambda x:x['created'],reverse=True),
                reset=[row('Resetta apprendimento','5 per continuare','Azzera rete, candidato, checkpoint, passi e tempo attuali. Mantiene nome, parametri e storico.','reset')])
