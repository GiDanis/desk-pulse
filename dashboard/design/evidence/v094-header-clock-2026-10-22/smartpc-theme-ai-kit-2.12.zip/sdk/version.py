"""Software version shared by runtime, installer and recursive release manifest."""
VERSION = '0.9.4-rc.1'
