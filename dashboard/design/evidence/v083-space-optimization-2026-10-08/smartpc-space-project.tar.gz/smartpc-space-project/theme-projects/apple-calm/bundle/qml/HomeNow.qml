pragma ComponentBehavior: Bound
import QtQuick
import SmartPC.ThemeApi 2.0
import "Format.js" as Format

ClockPage {
    id: root
    required property PageContext context
    ctx: context
    
}
