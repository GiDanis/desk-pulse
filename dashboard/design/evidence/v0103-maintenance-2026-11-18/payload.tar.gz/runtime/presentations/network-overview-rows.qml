import QtQuick
NetworkOverview {}
