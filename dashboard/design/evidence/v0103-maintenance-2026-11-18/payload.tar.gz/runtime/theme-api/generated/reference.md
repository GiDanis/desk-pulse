# SmartPC Theme API 2 — contract reference

**Canonical contract reference. Runtime registration, broker and private adapters are implemented in `theme_api.py`; this static check does not attest a running Qt backend.**

Generated from the four canonical JSON documents. Do not edit generated files.

API fingerprint: `5457c7f00f43ce140ca66be370757785510e99944eb4fa22ce84260d7d409dd0`

This fingerprint is independent from the schema-1 registry fingerprint.

## Surfaces

| Content ID | Context/version | Host | Legacy route | Actions |
| --- | --- | --- | --- | --- |
| account.usage | PageContext 2 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move |
| alerts.badge | NotificationContext 1 | notification | — | home, openInbox |
| alerts.banner.large | NotificationContext 1 | notification | — | home, openInbox |
| alerts.banner.small | NotificationContext 1 | notification | — | home, openInbox |
| alerts.detail | NotificationContext 1 | notification | alertDetail | back, home, scrollDetails |
| alerts.inbox | NotificationContext 1 | notification | alerts | back, home, moveSelection, openDetails, selectEvent |
| alerts.urgent | NotificationContext 1 | notification | — | dismiss, home, openDetails |
| casa.detail | CasaContext 1 | overlay | casaDetail | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, sources.refresh |
| casa.devices | CasaContext 1 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select |
| casa.overview | CasaContext 1 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select |
| device.info | InfoContext 1 | overlay | info | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, sources.refresh, tabs.select |
| home.clock | PageContext 2 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| home.day | PageContext 2 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| home.now | PageContext 2 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| network.detail | NetworkContext 1 | overlay | networkDetail | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, sources.refresh, network.favourite.toggle, navigation.tab.select |
| network.devices | NetworkContext 1 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, network.filter.step, selection.move, selection.select |
| network.overview | NetworkContext 1 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, network.filter.step, network.metrics.section, selection.move, selection.select |
| overlay.commands | CommandsContext 1 | overlay | commands | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| overlay.menu | MenuContext 1 | overlay | menu | menu.activate, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select |
| overlay.summary | SummaryContext 1 | overlay | detail | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move |
| racing.calendar | RacingContext 1 | overlay | racingList | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| racing.driver.detail | DriverContext 1 | overlay | racingDriver | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| racing.event.detail | RacingContext 1 | overlay | racingEvent | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| racing.live | RacingContext 1 | overlay | racingTiming | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| racing.overview | PageContext 2 | page | — | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| racing.session.detail | RacingContext 1 | overlay | racingSession | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| racing.standings | RacingContext 1 | overlay | racingTable | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| scene.main | SceneContext 1 | scene | — | — |
| settings.account | SettingsContext 1 | overlay | accountSettings | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.appearance | SettingsContext 1 | overlay | appearance | appearance.apply, appearance.cancel, appearance.export, appearance.import, appearance.notificationPreview, appearance.preview, appearance.reload, appearance.reset, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.appearance.notifications | SettingsContext 1 | overlay | appearanceNotifications | appearance.apply, appearance.cancel, appearance.export, appearance.import, appearance.notificationPreview, appearance.preview, appearance.reload, appearance.reset, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.casa | CasaContext 1 | overlay | casaSettings | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, sources.refresh, casa.favourite.toggle, casa.favourite.move, casa.config.reload, casa.polling.toggle |
| settings.display | SettingsContext 1 | overlay | system | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.index | SettingsContext 1 | overlay | settings | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate |
| settings.integrations | SettingsContext 1 | overlay | integrations | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate |
| settings.modules | SettingsContext 1 | overlay | modules | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.network | NetworkContext 1 | overlay | networkSettings | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, sources.refresh, network.favourite.toggle, network.favourite.move, network.config.reload, network.polling.toggle, network.alias.set |
| settings.notifications | SettingsContext 1 | overlay | notifications | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate |
| settings.notifications.categories | SettingsContext 1 | overlay | notificationCategories | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.notifications.quiet | SettingsContext 1 | overlay | notificationQuiet | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.racing | SettingsContext 1 | overlay | racingSettings | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.sources | SettingsContext 1 | overlay | sources | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, sources.refresh |
| settings.sport | SettingsContext 1 | overlay | sportSettings | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| shell.main | ShellContext 1 | shell | — | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| sport.fixtures | SportListContext 1 | overlay | sportList | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| sport.match.detail | MatchContext 1 | overlay | sportDetail | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| sport.overview | PageContext 2 | page | — | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| sport.standings | SportListContext 1 | overlay | sportTable | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| sport.team | PageContext 2 | page | — | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| sport.team.detail | TeamContext 1 | overlay | sportTeam | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| sport.team.picker | TeamPickerContext 1 | overlay | sportTeamPicker | details.open, details.refresh, details.scroll, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, tabs.select |
| weather.forecast | PageContext 2 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| weather.now | PageContext 2 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step |
| network.router | NetworkRouterContext 1 | overlay | networkRouter | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, network.metrics.entity, network.metrics.section, network.metrics.refresh, network.metrics.window, network.metrics.metric |
| network.wifi | NetworkWifiContext 1 | overlay | networkWifi | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, network.metrics.entity, network.metrics.section, network.metrics.refresh, network.metrics.window, network.metrics.metric |
| network.ports | NetworkPortsContext 1 | overlay | networkPorts | navigation.back, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select, details.open, network.metrics.entity, network.metrics.section, network.metrics.refresh, network.metrics.window, network.metrics.metric |
| sport.hub | SportHubContext 1 | page | — | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, selection.move, selection.select |
| settings.services | SettingsContext 1 | overlay | services | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.sports | SettingsContext 1 | overlay | sportModules | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| settings.appearance.management | SettingsContext 1 | overlay | themeManagement | navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.view.step, selection.move, selection.select, settings.activate, settings.adjust |
| casa.inventory | CasaContext 1 | overlay | casaList | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.tab.select, navigation.view.step, selection.move, selection.select |
| network.inventory | NetworkContext 1 | overlay | networkList | details.open, navigation.back, navigation.family.step, navigation.home, navigation.inbox, navigation.menu, navigation.tab.select, navigation.view.step, network.filter.step, selection.move, selection.select |
| game.track | GameContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, navigation.view.step, details.open, game.start, game.pause, game.observe, game.display, game.mode, game.configure, game.driver.select, game.driver.create, game.participant, game.option.step, game.option.activate, selection.move, selection.select |
| game.leaderboard | GameContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, navigation.view.step, details.open, game.start, game.pause, game.observe, game.display, game.mode, game.configure, game.driver.select, game.driver.create, game.participant, game.option.step, game.option.activate, selection.move, selection.select |
| game.progress | GameContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, navigation.view.step, details.open, game.start, game.pause, game.observe, game.display, game.mode, game.configure, game.driver.select, game.driver.create, game.participant, game.option.step, game.option.activate, selection.move, selection.select |
| game.menu | GameContext 1 | overlay | gameMenu | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, navigation.view.step, details.open, game.start, game.pause, game.observe, game.display, game.mode, game.configure, game.driver.select, game.driver.create, game.participant, game.option.step, game.option.activate, selection.move, selection.select |
| game.driver.details | GameContext 1 | overlay | gameDetails | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, navigation.view.step, details.open, game.start, game.pause, game.observe, game.display, game.mode, game.configure, game.driver.select, game.driver.create, game.participant, game.option.step, game.option.activate, selection.move, selection.select |
| game.driver | GameContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, navigation.view.step, details.open, game.start, game.pause, game.observe, game.display, game.mode, game.configure, game.driver.select, game.driver.create, game.participant, game.option.step, game.option.activate, selection.move, selection.select |
| aquarium.main | AquariumContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, aquarium.pause, aquarium.resume |
| aquarium.3d | Aquarium3DContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, aquarium.pause, aquarium.resume, aquarium.manage.open, aquarium.manage.key, aquarium.change, aquarium.prepared, aquarium.shown |
| aquarium.manage | AquariumManagementContext 1 | page | — | navigation.back, navigation.home, navigation.menu, navigation.inbox, navigation.family.step, aquarium.pause, aquarium.resume, aquarium.manage.open, aquarium.manage.key, aquarium.change, aquarium.prepared, aquarium.shown |

## Contexts

### SurfaceContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### PageContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 2} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| clock | ClockState | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| weather | WeatherData | required / nullable | {} |
| account | AccountData | required / nullable | {} |
| nextEvent | NextEventData | required / nullable | {} |
| sport | SportData | required / nullable | {} |
| team | TeamData | required / nullable | {} |
| fantasy | FantasyData | required / nullable | {} |
| racing | RacingData | required / nullable | {} |
| network | NetworkData | required / nullable | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### ShellContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| families | FamilyModel | required / non-null | {} |
| currentFamilyId | string | required / non-null | {} |
| currentViewId | string | required / non-null | {} |
| navigation | NavigationSnapshot | required / non-null | {} |
| layout | ShellLayout | required / non-null | {} |
| uiStatus | UiStatus | required / non-null | {} |
| clock | ClockState | optional / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### MenuContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| rows | MenuRowModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### CommandsContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| keyMap | CommandModel | required / non-null | {} |
| firstRun | bool | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### SummaryContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| familyId | string | required / non-null | {} |
| clock | ClockState | required / non-null | {} |
| weather | WeatherData | required / nullable | {} |
| nextEvent | NextEventData | required / nullable | {} |
| account | AccountData | optional / nullable | {} |
| rows | DashboardCardModel | optional / non-null | {} |
| selection | SelectionState | optional / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### SettingsContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| sectionId | string | required / non-null | {} |
| rows | SettingRowModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| draft | AppearanceDraftSummary | required / nullable | {} |
| operation | OperationState | required / non-null | {} |
| description | string | required / non-null | {} |
| feedback | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### InfoContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| tabs | TabModel | required / non-null | {} |
| rows | InfoRowModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| sources | SourceModel | required / non-null | {} |
| updatedAt | real | required / nullable | {"unit": "epochSeconds"} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### SportListContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| source | SourceState | required / non-null | {} |
| matches | MatchModel | required / non-null | {} |
| standings | StandingModel | required / non-null | {} |
| rounds | RoundModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| selectedRoundId | string | required / non-null | {} |
| favouriteTeamId | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### MatchContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| match | MatchData | required / non-null | {} |
| source | SourceState | required / non-null | {} |
| tabs | TabModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| fantasy | FantasyData | required / nullable | {} |
| detailOperation | OperationState | required / non-null | {} |
| origin | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### TeamContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| team | TeamData | required / non-null | {} |
| tabs | TabModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| calendarScope | string | required / non-null | {} |
| serieAOnly | bool | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### TeamPickerContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| teams | TeamIdentityModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| savedTeamId | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### RacingContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| kind | string | required / non-null | {"enum": ["f1", "motogp"]} |
| source | SourceState | required / non-null | {} |
| racing | RacingData | required / non-null | {} |
| event | RacingEventData | required / nullable | {} |
| session | RacingSessionData | required / nullable | {} |
| tabs | TabModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| detailOperation | OperationState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### DriverContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| kind | string | required / non-null | {"enum": ["f1", "motogp"]} |
| driver | DriverData | required / non-null | {} |
| source | SourceState | required / non-null | {} |
| live | bool | required / non-null | {} |
| tabs | TabModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| detailOperation | OperationState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### SceneContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | required / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| actor | ActorSnapshot | required / non-null | {} |
| configuration | SceneConfiguration | required / non-null | {} |
| occupiedRegions | array | required / non-null | {"items": "Rect", "maxItems": 64} |
| notification | NotificationEvent | required / nullable | {} |
| clock | ClockState | required / non-null | {} |
| suspended | bool | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### NotificationContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| apiVersion | int | required / non-null | {"const": 1} |
| contentId | string | required / non-null | {} |
| mode | string | required / non-null | {} |
| style | ThemeStyle | required / non-null | {} |
| visualStyle | NotificationStyle | required / non-null | {} |
| active | bool | required / non-null | {} |
| interactive | bool | required / non-null | {} |
| exiting | bool | required / non-null | {} |
| preview | bool | required / non-null | {} |
| ready | bool | required / non-null | {} |
| error | string | required / non-null | {} |
| viewportWidth | int | required / non-null | {"minimum": 0} |
| viewportHeight | int | required / non-null | {"minimum": 0} |
| event | legacyMap | required / non-null | {} |
| items | array | required / non-null | {"items": "legacyMap"} |
| selectedEventId | string | required / non-null | {} |
| unreadCount | int | required / non-null | {"minimum": 0} |
| sourceStatus | string | required / non-null | {} |
| scrollOffset | real | required / non-null | {"minimum": 0} |
| scrollMaximum | real | required / non-null | {"minimum": 0} |
| occupiedRegions | array | required / non-null | {"items": "Rect", "maxItems": 64} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| safeArea | Rect | required / non-null | {} |
| actions | array | required / non-null | {"items": "string"} |
| commandHints | array | required / non-null | {"items": "legacyMap"} |
| guideText | string | required / non-null | {} |
| sourceText | string | required / non-null | {} |
| validityText | string | required / non-null | {} |
| iconId | string | required / non-null | {} |
| eventData | NotificationEvent | optional / nullable | {} |
| itemModel | NotificationEventModel | optional / non-null | {} |
| commands | CommandModel | optional / non-null | {} |
| sourceMetadata | SourceState | optional / nullable | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |

Method `requestAction(string, string, legacyMap) → bool`.

Method `request(string, string, legacyMap) → ActionResult`.

Method `settleMotion() → void`.

Method `formatStamp(scalar) → string`.

Signal `settleMotionRequested()`.

### CasaContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| casa | CasaData | required / non-null | {} |
| source | SourceState | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| selectedDevice | CasaDevice | required / nullable | {} |
| rows | SettingRowModel | required / non-null | {} |
| description | string | required / non-null | {} |
| feedback | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### NetworkContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| source | SourceState | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| selectedDevice | NetworkDevice | required / nullable | {} |
| rows | NetworkSettingRowModel | required / non-null | {} |
| description | string | required / non-null | {} |
| feedback | string | required / non-null | {} |
| network | NetworkData | required / non-null | {} |
| detailRows | NetworkDetailModel | required / non-null | {} |
| deviceRows | NetworkDeviceModel | required / non-null | {} |
| overviewSection | string | required / non-null | {} |
| tools | NetworkMetricRowModel | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### NetworkRouterContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| metrics | NetworkMetricsView | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### NetworkWifiContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| metrics | NetworkMetricsView | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### NetworkPortsContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| metrics | NetworkMetricsView | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### SportHubContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| rows | SportDisciplineModel | required / non-null | {} |
| selection | SelectionState | required / non-null | {} |
| description | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### GameContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| game | legacyMap | required / non-null | {} |
| scene | legacyMap | required / non-null | {} |
| rows | array | required / non-null | {"items": "legacyMap"} |
| selectedIndex | int | required / non-null | {"minimum": 0} |
| section | string | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### AquariumContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| aquarium | AquariumSnapshot | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### Aquarium3DContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| scene | Aquarium3DState | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

### AquariumManagementContext

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| contentId | string | required / non-null | {} |
| contextVersion | int | required / non-null | {"const": 1} |
| surfaceInstanceId | string | required / non-null | {} |
| appearanceRevision | int | required / non-null | {"minimum": 0} |
| dataRevision | int | required / non-null | {"minimum": 0} |
| style | ThemeStyle | required / non-null | {} |
| lifecycle | SurfaceLifecycle | required / non-null | {} |
| viewport | Rect | required / non-null | {} |
| safeArea | Rect | required / non-null | {} |
| commands | CommandModel | required / non-null | {} |
| actions | ActionModel | required / non-null | {} |
| motionPolicy | MotionPolicy | optional / non-null | {} |
| dashboardSummary | DashboardSummary | optional / nullable | {} |
| management | AquariumManagement | required / non-null | {} |

Method `requestAction(string, string, legacyMap) → ActionResult`.

## DTOs

### Point

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| x | real | required / non-null | {} |
| y | real | required / non-null | {} |

### Rect

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| x | real | required / non-null | {} |
| y | real | required / non-null | {} |
| width | real | required / non-null | {"minimum": 0} |
| height | real | required / non-null | {"minimum": 0} |

### SourceState

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| status | string | required / non-null | {"enum": ["active", "updating", "stale", "offline", "error", "unavailable", "pending"]} |
| sourceId | string | required / non-null | {} |
| sourceLabel | string | required / non-null | {} |
| updatedAt | real | required / nullable | {"unit": "epochSeconds"} |
| checkedAt | real | required / nullable | {"unit": "epochSeconds"} |
| hasData | bool | required / non-null | {} |
| isStale | bool | required / non-null | {} |
| errorCode | string | required / non-null | {} |
| error | string | required / non-null | {} |
| dataRevision | string | required / non-null | {} |

### NumericValue

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| available | bool | required / non-null | {} |
| value | real | required / nullable | {} |
| unit | string | required / non-null | {} |
| displayText | string | required / non-null | {} |
| sourceRevision | string | required / non-null | {} |

### ScalarValue

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| available | bool | required / non-null | {} |
| value | scalar | required / nullable | {} |
| unit | string | required / non-null | {} |
| displayText | string | required / non-null | {} |

### SurfaceLifecycle

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| state | string | required / non-null | {"enum": ["preparing", "active", "suspended", "exiting", "disposed"]} |
| active | bool | required / non-null | {} |
| interactive | bool | required / non-null | {} |
| preview | bool | required / non-null | {} |
| generation | int | required / non-null | {"minimum": 0} |

### ClockState

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| epoch | real | required / non-null | {"unit": "epochSeconds"} |
| timeText | string | required / non-null | {} |
| dateText | string | required / non-null | {} |
| timezone | string | required / non-null | {} |
| locale | string | required / non-null | {} |
| night | bool | required / non-null | {} |

### SelectionState

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| selectedId | string | required / non-null | {} |
| tabId | string | required / non-null | {} |
| anchorId | string | required / non-null | {} |
| offset | real | required / non-null | {"minimum": 0} |
| index | int | required / non-null | {"minimum": -1} |
| count | int | required / non-null | {"minimum": 0} |

### OperationState

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| requestId | string | required / non-null | {} |
| status | string | required / non-null | {"enum": ["idle", "accepted", "pending", "completed", "failed", "rejected"]} |
| errorCode | string | required / non-null | {} |
| message | string | required / non-null | {} |

### ActionResult

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| accepted | bool | required / non-null | {} |
| requestId | string | required / non-null | {} |
| status | string | required / non-null | {"enum": ["accepted", "pending", "completed", "failed", "rejected"]} |
| errorCode | string | required / non-null | {} |

### Command

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| key | int | required / non-null | {"minimum": 1, "maximum": 9} |
| actionId | string | required / non-null | {} |
| targetId | string | required / non-null | {} |
| label | string | required / non-null | {} |
| enabled | bool | required / non-null | {} |

### AvailableAction

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| enabled | bool | required / non-null | {} |
| reason | string | required / non-null | {} |

### Tab

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| enabled | bool | required / non-null | {} |

### Family

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| available | bool | required / non-null | {} |
| visible | bool | required / non-null | {} |
| views | TabModel | required / non-null | {} |

### NavigationSnapshot

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| familyId | string | required / non-null | {} |
| viewId | string | required / non-null | {} |
| overlayId | string | required / non-null | {} |
| familyPosition | int | required / non-null | {"minimum": 0} |
| familyCount | int | required / non-null | {"minimum": 0} |
| viewPosition | int | required / non-null | {"minimum": 0} |
| viewCount | int | required / non-null | {"minimum": 0} |
| scopeId | string | required / non-null | {} |
| scopeLabel | string | required / non-null | {} |
| scopeCount | int | required / non-null | {"minimum": 0} |
| scopePosition | int | required / non-null | {"minimum": 0} |

### ShellLayout

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| header | Rect | required / non-null | {} |
| content | Rect | required / non-null | {} |
| guide | Rect | required / non-null | {} |
| sceneSafeRegions | array | required / non-null | {"items": "Rect", "maxItems": 64} |

### UiStatus

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| urgent | bool | required / non-null | {} |
| recovery | bool | required / non-null | {} |
| quiet | bool | required / non-null | {} |
| night | bool | required / non-null | {} |
| diagnostics | bool | required / non-null | {} |
| unreadCount | int | required / non-null | {"minimum": 0} |
| notificationsAvailable | bool | required / non-null | {} |

### AppearanceDraftSummary

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| editing | bool | required / non-null | {} |
| themeId | string | required / non-null | {} |
| paletteMode | string | required / non-null | {"enum": ["auto", "day", "night"]} |
| motionMode | string | required / non-null | {"enum": ["normal", "reduced", "off"]} |
| textScale | real | required / non-null | {"minimum": 0.85, "maximum": 1.1} |
| readyToApply | bool | required / non-null | {} |
| status | string | required / non-null | {} |
| error | string | required / non-null | {} |

### MenuRow

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| detail | string | required / non-null | {} |
| enabled | bool | required / non-null | {} |
| actionId | string | required / non-null | {} |
| targetId | string | required / non-null | {} |

### SettingOption

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| value | scalar | required / nullable | {} |

### SettingRow

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| detail | string | required / non-null | {} |
| control | string | required / non-null | {"enum": ["action", "toggle", "choice", "number", "theme", "transfer"]} |
| value | ScalarValue | required / non-null | {} |
| enabled | bool | required / non-null | {} |
| reason | string | required / non-null | {} |
| actionId | string | required / non-null | {} |
| targetId | string | required / non-null | {} |
| minimum | real | required / nullable | {} |
| maximum | real | required / nullable | {} |
| step | real | required / nullable | {} |
| options | SettingOptionModel | required / non-null | {} |

### InfoRow

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| value | ScalarValue | required / non-null | {} |
| detail | string | required / non-null | {} |
| sourceId | string | required / non-null | {} |

### WeatherForecast

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| date | string | required / non-null | {"format": "date"} |
| dayText | string | required / non-null | {} |
| code | int | required / non-null | {"minimum": -1} |
| description | string | required / non-null | {} |
| high | NumericValue | required / non-null | {} |
| low | NumericValue | required / non-null | {} |
| rainProbability | NumericValue | required / non-null | {} |

### WeatherData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| source | SourceState | required / non-null | {} |
| location | string | required / non-null | {} |
| code | int | required / non-null | {"minimum": -1} |
| description | string | required / non-null | {} |
| temperature | NumericValue | required / non-null | {} |
| feelsLike | NumericValue | required / non-null | {} |
| humidity | NumericValue | required / non-null | {} |
| precipitation | NumericValue | required / non-null | {} |
| rainProbability | NumericValue | required / non-null | {} |
| windSpeed | NumericValue | required / non-null | {} |
| windDirection | NumericValue | required / non-null | {} |
| windDirectionText | string | required / non-null | {} |
| gusts | NumericValue | required / non-null | {} |
| observationAt | real | required / nullable | {"unit": "epochSeconds"} |
| forecast | WeatherForecastModel | required / non-null | {} |

### NextEventData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| category | string | required / non-null | {} |
| startsAt | real | required / nullable | {"unit": "epochSeconds"} |
| whenText | string | required / non-null | {} |
| source | SourceState | required / non-null | {} |

### AccountWindow

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| usedPercent | NumericValue | required / non-null | {} |
| windowDurationMinutes | NumericValue | required / non-null | {} |
| resetsAt | real | required / nullable | {"unit": "epochSeconds"} |
| severity | string | required / non-null | {"enum": ["normal", "warning", "critical", "unavailable"]} |

### AccountData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| source | SourceState | required / non-null | {} |
| plan | string | required / non-null | {} |
| windows | AccountWindowModel | required / non-null | {} |
| resetCredits | NumericValue | required / non-null | {} |
| warningThreshold | int | required / non-null | {"minimum": 1, "maximum": 100} |
| criticalThreshold | int | required / non-null | {"minimum": 1, "maximum": 100} |
| credits | AccountCredits | optional / nullable | {} |

### TeamIdentity

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| shortName | string | required / non-null | {} |
| crestId | string | required / non-null | {} |

### MatchEvent

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| kind | string | required / non-null | {} |
| minute | NumericValue | required / non-null | {} |
| teamId | string | required / non-null | {} |
| playerId | string | required / non-null | {} |
| playerName | string | required / non-null | {} |
| text | string | required / non-null | {} |

### MatchStatistic

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| home | NumericValue | required / non-null | {} |
| away | NumericValue | required / non-null | {} |

### LineupPlayer

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| shirtNumber | NumericValue | required / non-null | {} |
| role | string | required / non-null | {} |
| group | string | required / non-null | {} |
| inMinute | NumericValue | required / non-null | {} |
| outMinute | NumericValue | required / non-null | {} |

### Lineup

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| teamId | string | required / non-null | {} |
| formation | string | required / non-null | {} |
| coach | string | required / non-null | {} |
| players | LineupPlayerModel | required / non-null | {} |

### MatchData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| competitionId | string | required / non-null | {} |
| competitionName | string | required / non-null | {} |
| season | string | required / non-null | {} |
| roundId | string | required / non-null | {} |
| source | SourceState | required / non-null | {} |
| providerMatchId | string | required / non-null | {} |
| status | string | required / non-null | {"enum": ["scheduled", "live", "half_time", "finished", "postponed", "cancelled", "suspended", "unavailable"]} |
| rawStatus | string | required / non-null | {} |
| home | TeamIdentity | required / non-null | {} |
| away | TeamIdentity | required / non-null | {} |
| homeScore | NumericValue | required / non-null | {} |
| awayScore | NumericValue | required / non-null | {} |
| kickoffAt | real | required / nullable | {"unit": "epochSeconds"} |
| whenText | string | required / non-null | {} |
| minute | NumericValue | required / non-null | {} |
| pendingVAR | bool | required / non-null | {} |
| venue | string | required / non-null | {} |
| events | MatchEventModel | required / non-null | {} |
| statistics | MatchStatisticModel | required / non-null | {} |
| lineups | LineupModel | required / non-null | {} |
| detailLoading | bool | required / non-null | {} |
| detailError | string | required / non-null | {} |
| detailFetchedAt | real | required / nullable | {"unit": "epochSeconds"} |

### Standing

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| entityId | string | required / non-null | {} |
| name | string | required / non-null | {} |
| position | NumericValue | required / non-null | {} |
| played | NumericValue | required / non-null | {} |
| points | NumericValue | required / non-null | {} |
| wins | NumericValue | required / non-null | {} |
| draws | NumericValue | required / non-null | {} |
| losses | NumericValue | required / non-null | {} |
| goalsFor | NumericValue | required / non-null | {} |
| goalsAgainst | NumericValue | required / non-null | {} |
| goalDifference | NumericValue | required / non-null | {} |

### Round

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |

### SportData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| source | SourceState | required / non-null | {} |
| competitionId | string | required / non-null | {} |
| competitionName | string | required / non-null | {} |
| season | string | required / non-null | {} |
| calendarScope | string | required / non-null | {} |
| matches | MatchModel | required / non-null | {} |
| standings | StandingModel | required / non-null | {} |
| teams | TeamIdentityModel | required / non-null | {} |
| rounds | RoundModel | required / non-null | {} |
| activeMatchIds | array | required / non-null | {"items": "string"} |
| favouriteTeamId | string | required / non-null | {} |
| hasLiveView | bool | required / non-null | {} |
| liveVerified | bool | required / non-null | {} |
| goalsEnabled | bool | required / non-null | {} |

### TeamData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| identity | TeamIdentity | required / non-null | {} |
| source | SourceState | required / non-null | {} |
| calendarScope | string | required / non-null | {} |
| fixtures | MatchModel | required / non-null | {} |
| squad | LineupPlayerModel | required / non-null | {} |
| info | InfoRowModel | required / non-null | {} |
| standing | Standing | required / nullable | {} |
| recordText | string | required / non-null | {} |
| cacheError | string | required / non-null | {} |

### FantasyBonus

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| count | NumericValue | required / non-null | {} |
| points | NumericValue | required / non-null | {} |

### FantasyPlayer

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| role | string | required / non-null | {} |
| shirtNumber | NumericValue | required / non-null | {} |
| group | string | required / non-null | {} |
| inMinute | NumericValue | required / non-null | {} |
| outMinute | NumericValue | required / non-null | {} |
| vote | NumericValue | required / non-null | {} |
| fantavote | NumericValue | required / non-null | {} |
| voteText | string | required / non-null | {} |
| fantavoteText | string | required / non-null | {} |
| withoutVote | bool | required / non-null | {} |
| bonuses | FantasyBonusModel | required / non-null | {} |

### FantasyTeam

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| players | FantasyPlayerModel | required / non-null | {} |
| total | NumericValue | required / non-null | {} |

### FantasyData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| source | SourceState | required / non-null | {} |
| matchId | string | required / non-null | {} |
| provisional | bool | required / non-null | {} |
| liveVerified | bool | required / non-null | {} |
| loading | bool | required / non-null | {} |
| teams | FantasyTeamModel | required / non-null | {} |
| message | string | required / non-null | {} |
| warning | string | required / non-null | {} |
| liveNotice | string | required / non-null | {} |
| cacheError | string | required / non-null | {} |

### RacingTiming

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| driverId | string | required / non-null | {} |
| driverName | string | required / non-null | {} |
| position | NumericValue | required / non-null | {} |
| lap | NumericValue | required / non-null | {} |
| time | NumericValue | required / non-null | {} |
| gap | NumericValue | required / non-null | {} |
| interval | NumericValue | required / non-null | {} |
| speed | NumericValue | required / non-null | {} |
| tyre | string | required / non-null | {} |
| compound | string | required / non-null | {} |
| status | string | required / non-null | {} |
| team | string | required / non-null | {} |
| points | NumericValue | required / non-null | {} |
| timeKind | string | required / non-null | {"enum": ["total", "best_lap", "last_lap", "reference", "unavailable"]} |
| resultText | string | required / non-null | {} |
| resultKind | string | required / non-null | {"enum": ["time", "gap", "status", "reported", "unavailable"]} |

### PitStop

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| lap | NumericValue | required / non-null | {} |
| duration | NumericValue | required / non-null | {} |
| stopNumber | NumericValue | required / non-null | {} |
| timeText | string | required / non-null | {} |

### LapTime

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| lap | NumericValue | required / non-null | {} |
| time | NumericValue | required / non-null | {} |
| position | NumericValue | required / non-null | {} |

### Stint

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| compound | string | required / non-null | {} |
| startLap | NumericValue | required / non-null | {} |
| endLap | NumericValue | required / non-null | {} |
| tyreAge | NumericValue | required / non-null | {} |

### DriverData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| team | string | required / non-null | {} |
| nationality | string | required / non-null | {} |
| number | NumericValue | required / non-null | {} |
| timing | RacingTiming | required / nullable | {} |
| detailRows | InfoRowModel | required / non-null | {} |
| pitStops | PitStopModel | required / non-null | {} |
| laps | LapTimeModel | required / non-null | {} |
| stints | StintModel | required / non-null | {} |

### RacingSessionData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| kind | string | required / non-null | {} |
| name | string | required / non-null | {} |
| startsAt | real | required / nullable | {"unit": "epochSeconds"} |
| endsAt | real | required / nullable | {"unit": "epochSeconds"} |
| status | string | required / non-null | {} |
| results | RacingTimingModel | required / non-null | {} |
| info | InfoRowModel | required / non-null | {} |
| source | SourceState | required / non-null | {} |

### RacingEventData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| roundId | string | required / non-null | {} |
| startsAt | real | required / nullable | {"unit": "epochSeconds"} |
| endsAt | real | required / nullable | {"unit": "epochSeconds"} |
| circuit | string | required / non-null | {} |
| sessions | RacingSessionModel | required / non-null | {} |
| info | InfoRowModel | required / non-null | {} |
| summary | InfoRowModel | required / non-null | {} |
| source | SourceState | required / non-null | {} |

### RaceMessage

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| text | string | required / non-null | {} |
| issuedAt | real | required / nullable | {"unit": "epochSeconds"} |
| severity | string | required / non-null | {} |

### RacingLiveData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| source | SourceState | required / non-null | {} |
| active | bool | required / non-null | {} |
| rows | RacingTimingModel | required / non-null | {} |
| messages | RaceMessageModel | required / non-null | {} |
| info | InfoRowModel | required / non-null | {} |

### RacingData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| source | SourceState | required / non-null | {} |
| kind | string | required / non-null | {"enum": ["f1", "motogp"]} |
| year | int | required / non-null | {"minimum": 1900, "maximum": 9999} |
| events | RacingEventModel | required / non-null | {} |
| standings | StandingModel | required / non-null | {} |
| constructors | StandingModel | required / non-null | {} |
| live | RacingLiveData | required / non-null | {} |
| detailLoading | bool | required / non-null | {} |
| detailError | string | required / non-null | {} |
| partialError | string | required / non-null | {} |

### NotificationEvent

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| revision | string | required / non-null | {} |
| rank | int | required / non-null | {"minimum": 0} |
| category | string | required / non-null | {} |
| severity | string | required / non-null | {} |
| weatherSeverity | string | required / non-null | {} |
| title | string | required / non-null | {} |
| body | string | required / non-null | {} |
| sourceId | string | required / non-null | {} |
| sourceLabel | string | required / non-null | {} |
| issuedAt | real | required / nullable | {"unit": "epochSeconds"} |
| expiresAt | real | required / nullable | {"unit": "epochSeconds"} |
| seen | bool | required / non-null | {} |
| bannerSize | string | required / non-null | {"enum": ["small", "large"]} |
| source | SourceState | required / nullable | {} |
| cancelled | bool | required / non-null | {} |
| expired | bool | required / non-null | {} |
| presented | bool | required / non-null | {} |
| deliveryState | string | required / non-null | {"enum": ["pending", "presented", "listed_capacity", "listed_late", "revoked", "expired", "unavailable"]} |

### MotionPolicy

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| mode | string | required / non-null | {"enum": ["normal", "reduced", "off"]} |
| suspended | bool | required / non-null | {} |
| urgent | bool | required / non-null | {} |

### ActorSnapshot

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| actorId | string | required / non-null | {} |
| pose | string | required / non-null | {} |
| locomotion | string | required / non-null | {} |
| sequence | int | required / non-null | {"minimum": 0} |
| paused | bool | required / non-null | {} |
| anchor | Point | required / non-null | {} |
| motionMode | string | required / non-null | {"enum": ["normal", "reduced", "off"]} |

### SceneConfiguration

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| enabled | bool | required / non-null | {} |
| rendererId | string | required / non-null | {} |
| mode | string | required / non-null | {"enum": ["actor", "canvas"]} |

### ThemeStyle

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| background | color | required / non-null | {} |
| backgroundOverlay | color | required / non-null | {} |
| surface | color | required / non-null | {} |
| surfaceFocused | color | required / non-null | {} |
| border | color | required / non-null | {} |
| divider | color | required / non-null | {} |
| textPrimary | color | required / non-null | {} |
| textSecondary | color | required / non-null | {} |
| accent | color | required / non-null | {} |
| bannerSurface | color | required / non-null | {} |
| debugSurface | color | required / non-null | {} |
| demoSurface | color | required / non-null | {} |
| radiusCard | int | required / non-null | {} |
| radiusRow | int | required / non-null | {} |
| radiusPill | int | required / non-null | {} |
| radiusButton | int | required / non-null | {} |
| spacing | int | required / non-null | {} |
| listRows | int | required / non-null | {} |
| borderWidth | int | required / non-null | {} |
| focusWidth | int | required / non-null | {} |
| textScale | real | required / non-null | {} |
| uiFamily | string | required / non-null | {} |
| numbersFamily | string | required / non-null | {} |
| displayFamily | string | required / non-null | {} |
| bodyWeight | int | required / non-null | {} |
| headingWeight | int | required / non-null | {} |
| font18 | int | required / non-null | {} |
| font19 | int | required / non-null | {} |
| font20 | int | required / non-null | {} |
| font21 | int | required / non-null | {} |
| font22 | int | required / non-null | {} |
| font23 | int | required / non-null | {} |
| font24 | int | required / non-null | {} |
| font25 | int | required / non-null | {} |
| font26 | int | required / non-null | {} |
| font27 | int | required / non-null | {} |
| font28 | int | required / non-null | {} |
| font29 | int | required / non-null | {} |
| font30 | int | required / non-null | {} |
| font31 | int | required / non-null | {} |
| font32 | int | required / non-null | {} |
| font33 | int | required / non-null | {} |
| font34 | int | required / non-null | {} |
| font35 | int | required / non-null | {} |
| font36 | int | required / non-null | {} |
| font37 | int | required / non-null | {} |
| font39 | int | required / non-null | {} |
| font40 | int | required / non-null | {} |
| font45 | int | required / non-null | {} |
| font46 | int | required / non-null | {} |
| font47 | int | required / non-null | {} |
| font52 | int | required / non-null | {} |
| font56 | int | required / non-null | {} |
| font65 | int | required / non-null | {} |
| font69 | int | required / non-null | {} |
| font139 | int | required / non-null | {} |
| font152 | int | required / non-null | {} |
| variant | string | required / non-null | {} |
| font44 | int | required / non-null | {} |
| compactRows | int | required / non-null | {} |
| overviewRows | int | required / non-null | {} |
| fantasyRows | int | required / non-null | {} |
| clockWeight | int | required / non-null | {} |
| radiusPanel | int | required / non-null | {} |
| radiusBadge | int | required / non-null | {} |
| radiusDense | int | required / non-null | {} |
| radiusMarker | int | required / non-null | {} |
| hairlineWidth | int | required / non-null | {} |
| semantic | SemanticPalette | required / non-null | {} |
| tokenSnapshot | legacyMap | optional / non-null | {} |

### NotificationStyle

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| background | color | required / non-null | {} |
| backgroundOverlay | color | required / non-null | {} |
| surface | color | required / non-null | {} |
| surfaceFocused | color | required / non-null | {} |
| border | color | required / non-null | {} |
| divider | color | required / non-null | {} |
| textPrimary | color | required / non-null | {} |
| textSecondary | color | required / non-null | {} |
| accent | color | required / non-null | {} |
| bannerSurface | color | required / non-null | {} |
| debugSurface | color | required / non-null | {} |
| demoSurface | color | required / non-null | {} |
| radiusCard | int | required / non-null | {} |
| radiusRow | int | required / non-null | {} |
| radiusPill | int | required / non-null | {} |
| radiusButton | int | required / non-null | {} |
| spacing | int | required / non-null | {} |
| listRows | int | required / non-null | {} |
| borderWidth | int | required / non-null | {} |
| focusWidth | int | required / non-null | {} |
| textScale | real | required / non-null | {} |
| uiFamily | string | required / non-null | {} |
| numbersFamily | string | required / non-null | {} |
| displayFamily | string | required / non-null | {} |
| bodyWeight | int | required / non-null | {} |
| headingWeight | int | required / non-null | {} |
| font18 | int | required / non-null | {} |
| font19 | int | required / non-null | {} |
| font20 | int | required / non-null | {} |
| font21 | int | required / non-null | {} |
| font22 | int | required / non-null | {} |
| font23 | int | required / non-null | {} |
| font24 | int | required / non-null | {} |
| font25 | int | required / non-null | {} |
| font26 | int | required / non-null | {} |
| font27 | int | required / non-null | {} |
| font28 | int | required / non-null | {} |
| font29 | int | required / non-null | {} |
| font30 | int | required / non-null | {} |
| font31 | int | required / non-null | {} |
| font32 | int | required / non-null | {} |
| font33 | int | required / non-null | {} |
| font34 | int | required / non-null | {} |
| font35 | int | required / non-null | {} |
| font36 | int | required / non-null | {} |
| font37 | int | required / non-null | {} |
| font39 | int | required / non-null | {} |
| font40 | int | required / non-null | {} |
| font45 | int | required / non-null | {} |
| font46 | int | required / non-null | {} |
| font47 | int | required / non-null | {} |
| font52 | int | required / non-null | {} |
| font56 | int | required / non-null | {} |
| font65 | int | required / non-null | {} |
| font69 | int | required / non-null | {} |
| font139 | int | required / non-null | {} |
| font152 | int | required / non-null | {} |
| variant | string | required / non-null | {} |
| font44 | int | required / non-null | {} |
| compactRows | int | required / non-null | {} |
| overviewRows | int | required / non-null | {} |
| fantasyRows | int | required / non-null | {} |
| clockWeight | int | required / non-null | {} |
| radiusPanel | int | required / non-null | {} |
| radiusBadge | int | required / non-null | {} |
| radiusDense | int | required / non-null | {} |
| radiusMarker | int | required / non-null | {} |
| hairlineWidth | int | required / non-null | {} |
| semantic | SemanticPalette | required / non-null | {} |
| tokenSnapshot | legacyMap | optional / non-null | {} |
| prefix | string | required / non-null | {} |
| surfaceColor | color | required / non-null | {} |
| noticeFocusedSurface | color | required / non-null | {} |
| titleColor | color | required / non-null | {} |
| bodyColor | color | required / non-null | {} |
| sourceColor | color | required / non-null | {} |
| noticeAccent | color | required / non-null | {} |
| noticeBorder | color | required / non-null | {} |
| noticeRadius | int | required / non-null | {} |
| noticeBorderWidth | int | required / non-null | {} |
| padding | int | required / non-null | {} |
| gap | int | required / non-null | {} |
| panelWidth | int | required / non-null | {} |
| panelHeight | int | required / non-null | {} |
| insetX | int | required / non-null | {} |
| insetY | int | required / non-null | {} |
| anchor | string | required / non-null | {} |
| titleSize | int | required / non-null | {} |
| bodySize | int | required / non-null | {} |
| sourceSize | int | required / non-null | {} |
| guideSize | int | required / non-null | {} |
| titleFamily | string | required / non-null | {} |
| bodyFamily | string | required / non-null | {} |
| sourceFamily | string | required / non-null | {} |
| guideFamily | string | required / non-null | {} |
| titleWeight | int | required / non-null | {} |
| noticeBodyWeight | int | required / non-null | {} |
| titleLines | int | required / non-null | {} |
| bodyLines | int | required / non-null | {} |
| showIcon | bool | required / non-null | {} |
| showSource | bool | required / non-null | {} |
| noticeRows | int | required / non-null | {} |
| layoutY | real | required / non-null | {} |
| mode | string | required / non-null | {"enum": ["small", "large", "urgent", "badge", "inbox", "detail"]} |
| guideColor | color | required / non-null | {} |
| badgeTextColor | color | required / non-null | {} |
| focusedTitleColor | color | required / non-null | {} |
| focusedBodyColor | color | required / non-null | {} |
| focusedSourceColor | color | required / non-null | {} |

### SemanticPalette

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| accentTextOnCanvas | color | required / non-null | {} |
| accentTextOnOverlay | color | required / non-null | {} |
| accentTextOnCard | color | required / non-null | {} |
| accentTextOnFocused | color | required / non-null | {} |
| warningOnCanvas | color | required / non-null | {} |
| warningOnOverlay | color | required / non-null | {} |
| warningOnCard | color | required / non-null | {} |
| warningOnFocused | color | required / non-null | {} |
| criticalOnCanvas | color | required / non-null | {} |
| criticalOnOverlay | color | required / non-null | {} |
| criticalOnCard | color | required / non-null | {} |
| criticalOnFocused | color | required / non-null | {} |
| accountCriticalOnCanvas | color | required / non-null | {} |
| accountCriticalOnOverlay | color | required / non-null | {} |
| accountCriticalOnCard | color | required / non-null | {} |
| accountCriticalOnFocused | color | required / non-null | {} |
| accentDecoration | color | optional / non-null | {} |
| focusIndicator | color | optional / non-null | {} |
| warningIndicator | color | optional / non-null | {} |
| criticalIndicator | color | optional / non-null | {} |

### CasaMetric

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| code | string | required / non-null | {} |
| label | string | required / non-null | {} |
| type | string | required / non-null | {} |
| value | scalar | required / nullable | {} |
| unit | string | required / non-null | {} |
| quality | string | required / non-null | {"enum": ["reported", "unverified"]} |
| checkedAt | real | required / non-null | {"minimum": 0} |
| stale | bool | required / non-null | {} |
| displayText | string | required / non-null | {} |
| previous | bool | required / non-null | {} |

### CasaDevice

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| category | string | required / non-null | {} |
| model | string | required / non-null | {} |
| productId | string | required / non-null | {} |
| online | bool | required / nullable | {} |
| present | bool | required / non-null | {} |
| missingCount | int | required / non-null | {"minimum": 0, "maximum": 2} |
| favourite | bool | required / non-null | {} |
| availability | string | required / non-null | {} |
| availabilityPrevious | bool | required / non-null | {} |
| previous | bool | required / non-null | {} |
| primaryText | string | required / non-null | {} |
| secondaryText | string | required / non-null | {} |
| iconId | string | required / non-null | {} |
| metrics | CasaMetricModel | required / non-null | {} |

### CasaData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| devices | CasaDeviceModel | required / non-null | {} |
| favourites | CasaDeviceModel | required / non-null | {} |
| configured | bool | required / non-null | {} |
| busy | bool | required / non-null | {} |
| polling | bool | required / non-null | {} |
| quotaConfigured | bool | required / non-null | {} |
| requests | int | required / non-null | {} |
| remaining | int | required / non-null | {} |
| modeText | string | required / non-null | {} |
| feedback | string | required / non-null | {} |
| readOnly | bool | required / non-null | {} |

### NetworkDetail

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| section | string | required / non-null | {} |
| title | string | required / non-null | {} |
| value | string | required / non-null | {} |
| detail | string | required / non-null | {} |

### NetworkDevice

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |
| originalName | string | required / non-null | {} |
| kind | string | required / non-null | {} |
| mac | string | required / non-null | {} |
| vendor | string | required / non-null | {} |
| interface | string | required / non-null | {} |
| primaryAddress | string | required / non-null | {} |
| connectionText | string | required / non-null | {} |
| statusText | string | required / non-null | {} |
| previous | bool | required / non-null | {} |
| favourite | bool | required / non-null | {} |
| lastSeen | real | required / nullable | {} |
| collectedAt | real | required / non-null | {} |
| details | NetworkDetailModel | required / non-null | {} |

### NetworkData

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| reachableText | string | required / non-null | {} |
| coverage | string | required / non-null | {} |
| wanText | string | required / non-null | {} |
| localText | string | required / non-null | {} |
| feedback | string | required / non-null | {} |
| modeText | string | required / non-null | {} |
| configured | bool | required / non-null | {} |
| hasInventory | bool | required / non-null | {} |
| busy | bool | required / non-null | {} |
| polling | bool | required / non-null | {} |
| readOnly | bool | required / non-null | {} |
| countCurrent | bool | required / non-null | {} |
| knownCount | int | required / non-null | {"minimum": 0} |
| devices | NetworkDeviceModel | required / non-null | {} |
| favourites | NetworkDeviceModel | required / non-null | {} |

### NetworkMetricRow

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| value | string | required / non-null | {} |
| detail | string | required / non-null | {} |
| targetId | string | required / non-null | {} |
| previous | bool | required / non-null | {} |

### NetworkMetricEntity

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| name | string | required / non-null | {} |

### NetworkChartPoint

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| time | real | required / non-null | {} |
| value | real | required / nullable | {} |
| breakBefore | bool | required / non-null | {} |

### NetworkChartSeries

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| label | string | required / non-null | {} |
| unit | string | required / non-null | {} |
| points | NetworkChartPointModel | required / non-null | {} |
| gaps | int | required / non-null | {} |

### NetworkChart

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| start | real | required / nullable | {} |
| end | real | required / nullable | {} |
| resolution | real | required / nullable | {} |
| rawPoints | int | required / non-null | {} |
| series | NetworkChartSeriesModel | required / non-null | {} |
| previous | bool | required / non-null | {} |
| period | string | required / non-null | {} |
| unit | string | required / non-null | {} |
| message | string | required / non-null | {} |

### NetworkMetricsView

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| title | string | required / non-null | {} |
| summary | string | required / non-null | {} |
| selectedLabel | string | required / non-null | {} |
| sourceText | string | required / non-null | {} |
| section | string | required / non-null | {} |
| busy | bool | required / non-null | {} |
| hasChart | bool | required / non-null | {} |
| rows | NetworkMetricRowModel | required / non-null | {} |
| entities | NetworkMetricEntityModel | required / non-null | {} |
| chart | NetworkChart | required / non-null | {} |

### SportDiscipline

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| detail | string | required / non-null | {} |
| enabled | bool | required / non-null | {} |
| actionId | string | required / non-null | {} |
| targetId | string | required / non-null | {} |
| iconId | string | required / non-null | {} |
| source | SourceState | required / non-null | {} |

### AccountCredits

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| unlimited | bool | required / non-null | {} |
| balance | ScalarValue | required / non-null | {} |

### DashboardCard

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| value | string | required / non-null | {} |
| subtitle | string | required / non-null | {} |
| detail | string | required / non-null | {} |
| icon | string | required / non-null | {} |
| targetId | string | required / non-null | {} |
| previous | bool | required / non-null | {} |
| valueSize | int | required / non-null | {} |
| rect | Rect | required / non-null | {} |
| unit | string | required / non-null | {} |

### DashboardSummary

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| subtitle | string | required / non-null | {} |
| detailTarget | string | required / non-null | {} |
| eventId | string | required / non-null | {} |
| sessionId | string | required / non-null | {} |
| cards | DashboardCardModel | required / non-null | {} |
| detailRows | DashboardCardModel | required / non-null | {} |
| chart | NetworkChart | optional / nullable | {} |

### AquariumSpecies

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| atlasUrl | string | required / non-null | {} |
| atlasWidth | int | required / non-null | {"minimum": 0} |
| atlasHeight | int | required / non-null | {"minimum": 0} |
| referenceSize | real | required / non-null | {"minimum": 0} |
| speed | real | required / non-null | {"minimum": 0} |
| tailFrequency | real | required / non-null | {"minimum": 0} |
| bodyRect | Rect | required / non-null | {} |
| tailRect | Rect | required / non-null | {} |
| finRect | Rect | required / non-null | {} |
| referenceRect | Rect | required / non-null | {} |
| tailAnchor | Point | required / non-null | {} |
| tailPivot | Point | required / non-null | {} |
| finAnchor | Point | required / non-null | {} |
| finPivot | Point | required / non-null | {} |
| spriteUrl | string | required / non-null | {} |

### AquariumInstance

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| speciesId | string | required / non-null | {} |
| depth | int | required / non-null | {"minimum": 0, "maximum": 2} |
| phase | real | required / non-null | {"minimum": 0, "maximum": 1} |
| startX | real | required / non-null | {"minimum": 0, "maximum": 1} |
| startY | real | required / non-null | {"minimum": 0, "maximum": 1} |

### AquariumSnapshot

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| sessionId | string | required / non-null | {} |
| configurationRevision | int | required / non-null | {"minimum": 0} |
| assetRevision | string | required / non-null | {} |
| status | string | required / non-null | {"enum": ["idle", "loading", "ready", "error"]} |
| errorCode | string | required / non-null | {} |
| errorText | string | required / non-null | {} |
| requestedPlayback | string | required / non-null | {"enum": ["playing", "paused"]} |
| effectivePlayback | string | required / non-null | {"enum": ["suspended", "running", "static", "error"]} |
| suspendReasons | array | required / non-null | {"items": "string", "maxItems": 16} |
| environmentId | string | required / non-null | {} |
| seed | int | required / non-null | {"minimum": 0, "maximum": 2147483647} |
| backgroundUrl | string | required / non-null | {} |
| species | array | required / non-null | {"items": "AquariumSpecies", "maxItems": 8} |
| instances | array | required / non-null | {"items": "AquariumInstance", "maxItems": 16} |

### AquariumFish3D

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| visitId | string | required / non-null | {} |
| operationId | string | required / non-null | {} |
| speciesId | string | required / non-null | {} |
| assetUrl | string | required / non-null | {} |
| name | string | required / non-null | {} |
| speciesName | string | required / non-null | {} |
| tint | color | required / non-null | {} |
| size | real | required / non-null | {} |
| speed | real | required / non-null | {} |
| frequency | real | required / non-null | {} |
| phase | real | required / non-null | {} |
| startX | real | required / non-null | {} |
| startY | real | required / non-null | {} |
| seed | int | required / non-null | {"minimum": 0} |
| depth | int | required / non-null | {"minimum": 0, "maximum": 2} |

### Aquarium3DState

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| status | string | required / non-null | {} |
| errorText | string | required / non-null | {} |
| sessionId | string | required / non-null | {} |
| assetRevision | string | required / non-null | {} |
| effectivePlayback | string | required / non-null | {} |
| populationRevision | int | required / non-null | {"minimum": 0} |
| clockHealthy | bool | required / non-null | {} |
| fish | array | required / non-null | {"items": "AquariumFish3D", "maxItems": 16} |
| pending | array | required / non-null | {"items": "AquariumFish3D", "maxItems": 1} |
| runtimeAvailable | bool | required / non-null | {} |

### AquariumManageRow

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| id | string | required / non-null | {} |
| title | string | required / non-null | {} |
| value | string | required / non-null | {} |
| detail | string | required / non-null | {} |

### AquariumManagement

| Read-only field | Type | Optional/nullable | Constraints |
| --- | --- | --- | --- |
| section | string | required / non-null | {} |
| title | string | required / non-null | {} |
| message | string | required / non-null | {} |
| selectedIndex | int | required / non-null | {"minimum": 0} |
| busy | bool | required / non-null | {} |
| nameEditing | bool | required / non-null | {} |
| rows | array | required / non-null | {"items": "AquariumManageRow", "maxItems": 256} |

## Models

| Model | Row type | Identity |
| --- | --- | --- |
| CommandModel | Command | id |
| ActionModel | AvailableAction | id |
| TabModel | Tab | id |
| FamilyModel | Family | id |
| MenuRowModel | MenuRow | id |
| SettingRowModel | SettingRow | id |
| SettingOptionModel | SettingOption | id |
| InfoRowModel | InfoRow | id |
| WeatherForecastModel | WeatherForecast | id |
| AccountWindowModel | AccountWindow | id |
| TeamIdentityModel | TeamIdentity | id |
| MatchEventModel | MatchEvent | id |
| MatchStatisticModel | MatchStatistic | id |
| LineupPlayerModel | LineupPlayer | id |
| LineupModel | Lineup | id |
| MatchModel | MatchData | id |
| StandingModel | Standing | id |
| RoundModel | Round | id |
| FantasyBonusModel | FantasyBonus | id |
| FantasyPlayerModel | FantasyPlayer | id |
| FantasyTeamModel | FantasyTeam | id |
| RacingTimingModel | RacingTiming | id |
| PitStopModel | PitStop | id |
| LapTimeModel | LapTime | id |
| StintModel | Stint | id |
| RacingSessionModel | RacingSessionData | id |
| RacingEventModel | RacingEventData | id |
| RaceMessageModel | RaceMessage | id |
| NotificationEventModel | NotificationEvent | id |
| SourceModel | SourceState | sourceId |
| CasaDeviceModel | CasaDevice | id |
| CasaMetricModel | CasaMetric | code |
| NetworkDetailModel | NetworkDetail | id |
| NetworkDeviceModel | NetworkDevice | id |
| NetworkSettingRowModel | SettingRow | id |
| NetworkMetricRowModel | NetworkMetricRow | id |
| NetworkMetricEntityModel | NetworkMetricEntity | id |
| NetworkChartPointModel | NetworkChartPoint | id |
| NetworkChartSeriesModel | NetworkChartSeries | id |
| SportDisciplineModel | SportDiscipline | id |
| DashboardCardModel | DashboardCard | id |

## Actions

Shape and per-surface allowlist checks do not authorize an action in the live app.

The runtime broker also checks lifecycle, generation and private router availability. The app router owns urgent priority and current backend availability.

| Action | Target | Required arguments |
| --- | --- | --- |
| navigation.home | optional | {} |
| navigation.back | optional | {} |
| navigation.menu | optional | {} |
| navigation.inbox | optional | {} |
| navigation.family.step | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| navigation.view.step | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| selection.move | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| selection.select | required | {} |
| tabs.select | required | {} |
| details.open | required | {} |
| details.scroll | optional | {"delta": {"type": "real"}} |
| details.refresh | optional | {} |
| settings.activate | required | {} |
| settings.adjust | required | {"direction": {"type": "int", "enum": [-1, 1]}} |
| sources.refresh | required | {} |
| appearance.preview | required | {} |
| appearance.apply | optional | {} |
| appearance.cancel | optional | {} |
| appearance.reset | optional | {} |
| appearance.reload | optional | {} |
| appearance.import | optional | {} |
| appearance.export | optional | {} |
| appearance.notificationPreview | optional | {"mode": {"type": "string", "enum": ["small", "large", "urgent", "badge", "inbox", "detail"]}} |
| openInbox | optional | {} |
| selectEvent | required | {} |
| moveSelection | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| openDetails | required | {} |
| scrollDetails | optional | {"delta": {"type": "real"}} |
| dismiss | required | {} |
| back | optional | {} |
| home | optional | {} |
| menu.activate | required | {} |
| casa.favourite.toggle | required | {} |
| casa.favourite.move | required | {"direction": {"type": "int", "enum": [-1, 1]}} |
| casa.config.reload | required | {} |
| casa.polling.toggle | required | {} |
| network.favourite.toggle | required | {} |
| network.favourite.move | required | {"direction": {"type": "int", "enum": [-1, 1]}} |
| network.config.reload | required | {} |
| network.polling.toggle | required | {} |
| network.alias.set | required | {"alias": {"type": "string", "maxLength": 80}} |
| network.filter.step | required | {"direction": {"type": "int", "enum": [-1, 1]}} |
| navigation.tab.select | required | {} |
| network.metrics.entity | required | {} |
| network.metrics.section | required | {} |
| network.metrics.refresh | required | {} |
| network.metrics.window | required | {"direction": {"type": "int", "enum": [-1, 1]}} |
| network.metrics.metric | required | {"direction": {"type": "int", "enum": [-1, 1]}} |
| game.start | optional | {} |
| game.pause | optional | {} |
| game.observe | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| game.display | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| game.option.step | optional | {"direction": {"type": "int", "enum": [-1, 1]}} |
| game.option.activate | required | {} |
| game.driver.select | required | {} |
| game.participant | required | {} |
| game.mode | optional | {"mode": {"type": "string", "enum": ["impara", "gara", "prova", "campione", "qualifica", "impara_infinito", "impara_sorpasso"]}} |
| game.configure | optional | {"profile": {"type": "legacyMap"}} |
| game.driver.create | optional | {"name": {"type": "string", "maxLength": 40}} |
| aquarium.pause | optional | {} |
| aquarium.resume | optional | {} |
| aquarium.manage.open | optional | {} |
| aquarium.prepared | optional | {} |
| aquarium.shown | optional | {} |
| aquarium.manage.key | optional | {"key": {"type": "int", "minimum": 1, "maximum": 9, "required": true}} |
| aquarium.change | optional | {"operation": {"type": "string", "enum": ["add", "replace", "remove", "save", "pool"], "required": true}, "species": {"type": "string", "maxLength": 128, "required": false}, "fishId": {"type": "string", "maxLength": 128, "required": false}, "name": {"type": "string", "maxLength": 128, "required": false}, "variant": {"type": "string", "maxLength": 128, "required": false}, "nextSpecies": {"type": "string", "maxLength": 128, "required": false}, "days": {"type": "int", "minimum": 0, "maximum": 3650, "required": false}, "revision": {"type": "int", "minimum": 0, "required": false}} |

## Semantic roles

The usage graph is a contract. Runtime foreground resolution and contrast checks are supplied by the application resolver.

| Usage | Foreground role | Background token | Minimum | Kind |
| --- | --- | --- | --- | --- |
| accentTextOnCanvas | accentTextOnCanvas | colors.background | 4.5 | text |
| accentTextOnOverlay | accentTextOnOverlay | colors.backgroundOverlay | 4.5 | text |
| accentTextOnCard | accentTextOnCard | colors.surface | 4.5 | text |
| accentTextOnFocused | accentTextOnFocused | colors.surfaceFocused | 4.5 | text |
| warningOnCanvas | warningOnCanvas | colors.background | 4.5 | text |
| warningOnOverlay | warningOnOverlay | colors.backgroundOverlay | 4.5 | text |
| warningOnCard | warningOnCard | colors.surface | 4.5 | text |
| warningOnFocused | warningOnFocused | colors.surfaceFocused | 4.5 | text |
| criticalOnCanvas | criticalOnCanvas | colors.background | 4.5 | text |
| criticalOnOverlay | criticalOnOverlay | colors.backgroundOverlay | 4.5 | text |
| criticalOnCard | criticalOnCard | colors.surface | 4.5 | text |
| criticalOnFocused | criticalOnFocused | colors.surfaceFocused | 4.5 | text |
| accountCriticalOnCanvas | accountCriticalOnCanvas | colors.background | 4.5 | text |
| accountCriticalOnOverlay | accountCriticalOnOverlay | colors.backgroundOverlay | 4.5 | text |
| accountCriticalOnCard | accountCriticalOnCard | colors.surface | 4.5 | text |
| accountCriticalOnFocused | accountCriticalOnFocused | colors.surfaceFocused | 4.5 | text |
| focus-colors.surface | focusIndicator | colors.surface | 3 | indicator |
| focus-colors.surfaceFocused | focusIndicator | colors.surfaceFocused | 3 | indicator |
| focus-colors.backgroundOverlay | focusIndicator | colors.backgroundOverlay | 3 | indicator |
| warningIndicator-urgent | warningIndicator | notifications.urgent.surface | 3 | indicator |
| criticalIndicator-urgent | criticalIndicator | notifications.urgent.surface | 3 | indicator |
| notifications.small.guideColor | notifications.small.guideColor | notifications.small.surface | 4.5 | text |
| notifications.small.badgeTextColor | notifications.small.badgeTextColor | notifications.small.surface | 4.5 | text |
| notifications.small.titleColor | notifications.small.titleColor | notifications.small.surface | 4.5 | text |
| notifications.small.bodyColor | notifications.small.bodyColor | notifications.small.surface | 4.5 | text |
| notifications.small.sourceColor | notifications.small.sourceColor | notifications.small.surface | 4.5 | text |
| notifications.small.focusedTitleColor | notifications.small.focusedTitleColor | notifications.small.surface | 4.5 | text |
| notifications.small.focusedBodyColor | notifications.small.focusedBodyColor | notifications.small.surface | 4.5 | text |
| notifications.small.focusedSourceColor | notifications.small.focusedSourceColor | notifications.small.surface | 4.5 | text |
| notifications.small.focus | focusIndicator | notifications.small.surface | 3 | indicator |
| notifications.large.guideColor | notifications.large.guideColor | notifications.large.surface | 4.5 | text |
| notifications.large.badgeTextColor | notifications.large.badgeTextColor | notifications.large.surface | 4.5 | text |
| notifications.large.titleColor | notifications.large.titleColor | notifications.large.surface | 4.5 | text |
| notifications.large.bodyColor | notifications.large.bodyColor | notifications.large.surface | 4.5 | text |
| notifications.large.sourceColor | notifications.large.sourceColor | notifications.large.surface | 4.5 | text |
| notifications.large.focusedTitleColor | notifications.large.focusedTitleColor | notifications.large.surface | 4.5 | text |
| notifications.large.focusedBodyColor | notifications.large.focusedBodyColor | notifications.large.surface | 4.5 | text |
| notifications.large.focusedSourceColor | notifications.large.focusedSourceColor | notifications.large.surface | 4.5 | text |
| notifications.large.focus | focusIndicator | notifications.large.surface | 3 | indicator |
| notifications.urgent.guideColor | notifications.urgent.guideColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.badgeTextColor | notifications.urgent.badgeTextColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.titleColor | notifications.urgent.titleColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.bodyColor | notifications.urgent.bodyColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.sourceColor | notifications.urgent.sourceColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.focusedTitleColor | notifications.urgent.focusedTitleColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.focusedBodyColor | notifications.urgent.focusedBodyColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.focusedSourceColor | notifications.urgent.focusedSourceColor | notifications.urgent.surface | 4.5 | text |
| notifications.urgent.focus | focusIndicator | notifications.urgent.surface | 3 | indicator |
| notifications.badge.guideColor | notifications.badge.guideColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.badgeTextColor | notifications.badge.badgeTextColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.titleColor | notifications.badge.titleColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.bodyColor | notifications.badge.bodyColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.sourceColor | notifications.badge.sourceColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.focusedTitleColor | notifications.badge.focusedTitleColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.focusedBodyColor | notifications.badge.focusedBodyColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.focusedSourceColor | notifications.badge.focusedSourceColor | notifications.badge.surface | 4.5 | text |
| notifications.badge.focus | focusIndicator | notifications.badge.surface | 3 | indicator |
| notifications.inbox.guideColor | notifications.inbox.guideColor | notifications.inbox.surface | 4.5 | text |
| notifications.inbox.badgeTextColor | notifications.inbox.badgeTextColor | notifications.inbox.surface | 4.5 | text |
| notifications.inbox.titleColor | notifications.inbox.titleColor | notifications.inbox.surface | 4.5 | text |
| notifications.inbox.bodyColor | notifications.inbox.bodyColor | notifications.inbox.surface | 4.5 | text |
| notifications.inbox.sourceColor | notifications.inbox.sourceColor | notifications.inbox.surface | 4.5 | text |
| notifications.inbox.focusedTitleColor | notifications.inbox.focusedTitleColor | notifications.inbox.focusedSurface | 4.5 | text |
| notifications.inbox.focusedBodyColor | notifications.inbox.focusedBodyColor | notifications.inbox.focusedSurface | 4.5 | text |
| notifications.inbox.focusedSourceColor | notifications.inbox.focusedSourceColor | notifications.inbox.focusedSurface | 4.5 | text |
| notifications.inbox.focus | focusIndicator | notifications.inbox.focusedSurface | 3 | indicator |
| notifications.detail.guideColor | notifications.detail.guideColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.badgeTextColor | notifications.detail.badgeTextColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.titleColor | notifications.detail.titleColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.bodyColor | notifications.detail.bodyColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.sourceColor | notifications.detail.sourceColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.focusedTitleColor | notifications.detail.focusedTitleColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.focusedBodyColor | notifications.detail.focusedBodyColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.focusedSourceColor | notifications.detail.focusedSourceColor | notifications.detail.surface | 4.5 | text |
| notifications.detail.focus | focusIndicator | notifications.detail.surface | 3 | indicator |
