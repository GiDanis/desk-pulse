"""Software version shared by runtime, installer and recursive release manifest."""
VERSION = '0.8.6-rc.2'
