import QtQuick

DetailVisual {}
