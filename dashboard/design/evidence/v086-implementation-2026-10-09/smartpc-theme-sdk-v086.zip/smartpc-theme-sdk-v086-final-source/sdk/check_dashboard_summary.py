"""Qualification of dashboard priorities, missing values and mixed freshness."""
import unittest
from dashboard_summary import build_summary, environment_devices


class DashboardSummaryTests(unittest.TestCase):
    def project(self, view, data, status='active', **extra):
        envelope = {'status': status, 'source': 'fixture', 'updatedAt': 1000, 'data': data}
        payload = {**extra}
        model = {}
        if view.startswith('sport-'):
            payload['dashboardSport' if view == 'sport-sport' else 'dashboardRacing'] = envelope
        elif view.startswith('casa-'):
            model['casa'] = envelope
        elif view.startswith('rete-'):
            payload['networkState'] = envelope
        else:
            model['weather'] = envelope
        return build_summary(view, payload, model, 1000)

    def test_racing_session_after_event_start_is_not_lost(self):
        data = {'events': [{'id': 'gp', 'name': 'GP', 'start': 900, 'sessions': [
            {'id': 'p', 'name': 'Prove', 'start': 900}, {'id': 'q', 'name': 'Qualifiche', 'start': 1200},
            {'id': 'race', 'name': 'Gara', 'start': 1800}]}]}
        result = self.project('sport-f1', data)
        self.assertEqual(result['eventId'], 'gp')
        self.assertEqual(result['sessionId'], 'q')
        self.assertEqual(result['cards'][0]['title'], 'Qualifiche')

    def test_racing_clock_never_proves_live(self):
        data = {'events': [{'id': 'gp', 'sessions': [{'id': 'race', 'start': 990}]}],
                'live': {'isLive': True, 'eventId': 'gp', 'sessionId': 'race'}}
        for status, verified in [('active', False), ('offline', True), ('stale', True)]:
            data['liveVerified'] = verified
            result = self.project('sport-f1', data, status)
            self.assertFalse(any(c['value'] == 'In diretta' for c in result['cards']))

    def test_verified_racing_live_precedes_future(self):
        data = {'liveVerified': True, 'events': [{'id': 'gp', 'sessions': [
            {'id': 'live', 'name': 'Gara', 'start': 990}, {'id': 'next', 'start': 1200}]}],
                'live': {'isLive': True, 'eventId': 'gp', 'sessionId': 'live'}}
        self.assertEqual(self.project('sport-f1', data)['cards'][0]['value'], 'In diretta')

    def test_missing_score_and_real_zero_are_distinct(self):
        data = {'lastFinished': [{'canonicalMatchId': 'a', 'status': 'finished', 'homeScore': 0, 'awayScore': None}]}
        self.assertEqual(self.project('sport-sport', data)['cards'][0]['value'], '0 – —')

    def test_cancelled_match_not_next(self):
        data = {'fixtures': [{'canonicalMatchId': 'a', 'kickoffUtc': 1200, 'status': 'cancelled'},
                             {'canonicalMatchId': 'b', 'kickoffUtc': 1300, 'status': 'scheduled'}]}
        self.assertEqual(self.project('sport-sport', data)['cards'][0]['id'], 'b')

    def test_environment_uses_verified_codes_not_names(self):
        data = {'devices': [{'id': 'fake', 'name': 'Temperatura salotto', 'metrics': []},
                            {'id': 'raw', 'metrics': [{'code': 'va_temperature', 'quality': 'unverified'}]},
                            {'id': 'real', 'name': 'Sensore', 'metrics': [{'code': 'va_temperature', 'quality': 'reported',
                             'value': 0, 'displayText': '0 °C', 'previous': True}]}]}
        self.assertEqual([r['id'] for r in environment_devices(data)], ['real'])
        summary = self.project('casa-ambiente', data)
        self.assertEqual(summary['cards'][0]['value'], '0 °C')
        self.assertTrue(summary['cards'][0]['previous'])

    def test_saved_online_not_counted_current(self):
        data = {'devices': [{'id': 'a', 'online': True, 'availabilityPrevious': True},
                            {'id': 'b', 'online': False, 'availabilityPrevious': False}]}
        self.assertEqual(self.project('casa-dispositivi', data)['cards'][1]['value'], '0')
        data['devices'][1]['availabilityPrevious'] = True
        self.assertEqual(self.project('casa-dispositivi', data)['cards'][1]['value'], '—')

    def test_unknown_cloud_availability_is_not_zero(self):
        data={'devices':[{'id':'a','online':None,'availabilityPrevious':False}]}
        self.assertEqual(self.project('casa-dispositivi',data)['cards'][1]['value'],'—')

    def test_two_favourites_use_full_height(self):
        data={'favourites':[{'id':'a','name':'A'},{'id':'b','name':'B'}]}
        result=self.project('casa-preferiti',data)
        self.assertEqual([c['rect']['height'] for c in result['cards']],[504,504])

    def test_soccer_unverified_live_is_never_promoted(self):
        data={'activeMatches':[{'canonicalMatchId':'a','status':'live','isLive':True,'kickoffUtc':990}],
              'fixtures':[{'canonicalMatchId':'b','status':'scheduled','kickoffUtc':1200}]}
        self.assertEqual(self.project('sport-sport',data)['eventId'],'b')
        data['activeLiveVerified']=True
        self.assertEqual(self.project('sport-sport',data)['eventId'],'a')
        self.assertEqual(self.project('sport-sport',data,'offline')['eventId'],'b')

    def test_reachability_is_not_total_inventory(self):
        data = {'hasInventory': True, 'devices': [{'id': 'a', 'name': 'A', 'statusText': 'Raggiungibile secondo box', 'previous': True},
                                                {'id': 'b', 'name': 'B', 'statusText': 'Non raggiungibile secondo box', 'previous': False}]}
        result = self.project('rete-dispositivi', data)
        self.assertEqual(result['cards'][0]['value'], '2')
        self.assertEqual(result['cards'][1]['value'], '0')

    def test_wan_freshness_is_local(self):
        router = {'summary': 'FTTH · up', 'rows': [{'id': 'wan:down', 'value': '0 Mbit/s', 'previous': False},
                                                  {'id': 'wan:up', 'value': '2 Mbit/s', 'previous': True}]}
        result = self.project('rete-traffico', {}, dashboardRouter=router)
        self.assertEqual(result['cards'][0]['value'], '0')
        self.assertEqual(result['cards'][0]['unit'], 'Mbit/s')
        self.assertFalse(result['cards'][0]['previous'])
        self.assertTrue(result['cards'][1]['previous'])

    def test_account_details_keep_previous_source_and_real_zero(self):
        from theme_api import normalize_legacy
        model={'account':{'status':'offline','source':'Account fixture','updatedAt':900,'data':{
            'windows':[{'label':'5 ore','usedPercent':0,'windowDurationMins':300}],
            'credits':{'unlimited':False,'balance':0}}}}
        result=normalize_legacy('overlay.summary',{'familyId':'account','model':model})
        self.assertEqual(result['rows'][0]['value'],'0%')
        self.assertEqual(next(r for r in result['rows'] if r['id']=='credits')['value'],'0')
        self.assertTrue(all('Dato precedente' in r['detail'] and 'Account fixture' in r['detail'] for r in result['rows']))

    def test_layout_has_no_unused_lower_quadrant(self):
        data = {'events': [{'id': 'gp', 'name': 'GP', 'circuit': 'Circuito', 'sessions': [
            {'id': 'q', 'name': 'Qualifiche', 'start': 1200}, {'id': 'race', 'name': 'Gara', 'start': 1800}]}],
                'standings': [{'name': 'Pilota', 'points': 10}]}
        result = self.project('sport-f1', data)
        self.assertEqual(len(result['cards']), 4)
        self.assertEqual(sum(c['rect']['width'] * c['rect']['height'] for c in result['cards']), 400*504 + 496*244 + 2*240*244)
        for c in result['cards']:
            r = c['rect']
            self.assertLessEqual(r['x'] + r['width'], 912)
            self.assertLessEqual(r['y'] + r['height'], 504)


if __name__ == '__main__':
    unittest.main()
