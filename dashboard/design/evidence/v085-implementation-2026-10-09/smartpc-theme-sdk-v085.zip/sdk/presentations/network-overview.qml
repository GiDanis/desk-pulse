import QtQuick
NetworkOverview { }
