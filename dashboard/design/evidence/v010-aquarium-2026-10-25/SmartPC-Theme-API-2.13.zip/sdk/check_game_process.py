"""Local transport fragmentation/backpressure and Qt-safe process launch."""
from pathlib import Path
import os,queue,tempfile,threading,time,unittest
from unittest.mock import patch
from game_process import ParentLink,ChildLink,ChildFrames,extract,pack,spawn_role
from game_store import GameStore


class ProcessChecks(unittest.TestCase):
    def test_large_metadata_packet_fragmentation_and_bounded_frames(self):
        parent=ParentLink();child=ChildLink(str(parent.path));frame=ChildFrames(child)
        data={'text':'x'*600000};error=[]
        def send():
            try:
                for i in range(30):
                    try:frame.put_nowait(dict(sequence=i,payload='y'*40000))
                    except queue.Full:pass
                child.send(data)
            except Exception as e:error.append(e)
        thread=threading.Thread(target=send);thread.start();deadline=time.monotonic()+5
        try:
            while not parent.events and time.monotonic()<deadline:parent.pump();time.sleep(.001)
            thread.join(1)
            self.assertFalse(thread.is_alive());self.assertFalse(error)
            self.assertEqual(parent.recv(),data);self.assertLessEqual(len(parent.frames),2)
        finally:child.close();parent.close()
        encoded=pack('event',{'n':7});buffer=bytearray()
        for byte in encoded[:-1]:buffer.append(byte);self.assertEqual(extract(buffer),[])
        buffer.append(encoded[-1]);self.assertEqual(extract(buffer),[('event',{'n':7})])

    def test_dedicated_metadata_process_uses_posix_spawn(self):
        with tempfile.TemporaryDirectory() as root:
            GameStore(root)
            with patch('os.posix_spawn',wraps=os.posix_spawn) as spawn:
                process,link,_=spawn_role('metadata',root)
            try:
                self.assertEqual(spawn.call_count,1)
                link.send((1,'','oval-1','impara'));deadline=time.monotonic()+10
                while not link.poll() and time.monotonic()<deadline:time.sleep(.005)
                result=link.recv();self.assertEqual(len(result['drivers']),5);self.assertEqual(result['ticket'],1)
                link.send(None);process.join(3);self.assertFalse(process.is_alive())
            finally:
                if process.is_alive():process.kill();process.join(1)
                process.close();link.close()


if __name__=='__main__':unittest.main()
