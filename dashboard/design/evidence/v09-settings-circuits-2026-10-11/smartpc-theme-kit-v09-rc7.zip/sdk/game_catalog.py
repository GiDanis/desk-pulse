"""Versioned simulation content; SI units, independent of drivers and QML."""
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
from functools import lru_cache
from copy import deepcopy


@dataclass(frozen=True)
class TrackSpec:
    id: str = 'oval-1'
    name: str = 'Ovale'
    revision: int = 1
    half_straight: float = 36.0
    radius: float = 31.0
    road_width: float = 10.0


@dataclass(frozen=True)
class VehicleSpec:
    id: str = 'standard-1'
    length: float = 4.4
    width: float = 1.8
    wheelbase: float = 2.65
    mass: float = 1200.0
    power: float = 85000.0
    drive_force: float = 6500.0
    brake_force: float = 10000.0
    yaw_inertia: float = 1700.0
    corner_stiffness: float = 38000.0
    max_steer: float = 0.52
    steer_rate: float = 1.8


@dataclass(frozen=True)
class SurfaceProfile:
    id: str = 'asphalt'
    grip: float = 0.95
    rolling: float = 0.015


@dataclass(frozen=True)
class ConditionProfile:
    id: str = 'dry'
    grip_factor: float = 1.0


@dataclass(frozen=True)
class TireProfile:
    id: str = 'standard'
    grip_factor: float = 1.0


PHYSICS_VERSION = 'f1-2'
OBSERVATION_VERSION = 'race-32-v1'
ACTION_VERSION = 'steer-throttle-brake-v1'
OBSERVATION_SIZE = 32  # numeric9 + lane offset/heading + 3 opponents × 7
TRACK = TrackSpec()
VEHICLE = VehicleSpec()
SURFACE = SurfaceProfile()
CONDITION = ConditionProfile()
TIRE = TireProfile()


TRACKS = ({'id':'oval-1','name':'Ovale','revision':1},
          {'id':'technical-1','name':'Circuito Tecnico','revision':1})


@lru_cache(maxsize=4)
def _track_data(identity):
    if identity=='oval-1':return asdict(TRACK)
    if identity!='technical-1':raise ValueError('Circuito sconosciuto')
    return json.loads(Path(__file__).with_name('game-tracks').joinpath(identity+'.json').read_text())


def track_data(identity='oval-1'):return deepcopy(_track_data(identity))


def configuration(track_id='oval-1'):
    result = {name: asdict(value) for name, value in (
        ('track', TRACK), ('vehicle', VEHICLE), ('surface', SURFACE),
        ('condition', CONDITION), ('tire', TIRE))}
    result.update(physics=PHYSICS_VERSION, observation=OBSERVATION_VERSION,
                  action=ACTION_VERSION, decisionHz=60, substeps=2)
    result['track']=track_data(track_id)
    return result


@lru_cache(maxsize=4)
def scope_hash(track_id='oval-1'):
    return hashlib.sha256(json.dumps(configuration(track_id), sort_keys=True).encode()).hexdigest()


def qualified(driver,track_id='oval-1'):
    if not driver or not driver.get('policy'):return False
    champion=(driver.get('curriculum') or {}).get('champion') or {}
    proof=champion.get('proof') or {}
    return proof.get('scope')==scope_hash(track_id) and proof.get('candidateHash')==driver['policy'] and proof.get('candidate',{}).get('valid',0)>=9


def race_eligible(driver,track_id='oval-1'):
    # Preserve the legacy oval roster, including explicitly previous models.
    return bool(driver and driver.get('policy')) and (track_id=='oval-1' or qualified(driver,track_id))
